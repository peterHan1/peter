import weexComponent from "./hot-home-weex.vue"
weexComponent.el = '#weex'
export default new Vue(weexComponent)

