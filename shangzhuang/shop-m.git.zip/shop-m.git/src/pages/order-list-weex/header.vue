<template>
  <div>
    <slot></slot>
  </div>
</template>

<style scoped>
  
</style>

<script>
  module.exports = {

  }
</script>