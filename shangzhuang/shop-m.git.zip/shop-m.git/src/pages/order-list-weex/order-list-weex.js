import weexComponent from "./order-list-weex.vue"
weexComponent.el = '#weex'
export default new Vue(weexComponent)

