import weexComponent from "./my-cards-weex.vue"
weexComponent.el = '#weex'
export default new Vue(weexComponent)

