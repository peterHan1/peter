import weexComponent from "./hot-recommend-weex.vue"
weexComponent.el = '#weex'
export default new Vue(weexComponent)

