import weexComponent from "./shop-order-weex.vue"
weexComponent.el = '#weex'
export default new Vue(weexComponent)

