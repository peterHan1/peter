import weexComponent from "./hot-material-weex.vue"
weexComponent.el = '#weex'
export default new Vue(weexComponent)

