// require('./alert.we');
var confirm = require('./confirm.vue');
var notice = require('./notice.vue');
module.exports = {
  confirm: confirm,
  notice: notice
}