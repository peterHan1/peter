import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'

const _f5a7c09c = () => interopDefault(import('..\\pages\\api.js' /* webpackChunkName: "pages_api" */))
const _c3b84e74 = () => interopDefault(import('..\\pages\\project\\index.vue' /* webpackChunkName: "pages_project_index" */))
const _176395df = () => interopDefault(import('..\\pages\\appraisal\\explain.vue' /* webpackChunkName: "pages_appraisal_explain" */))
const _96723fae = () => interopDefault(import('..\\pages\\appraisal\\indexs.vue' /* webpackChunkName: "pages_appraisal_indexs" */))
const _de817734 = () => interopDefault(import('..\\pages\\appraisal\\list.vue' /* webpackChunkName: "pages_appraisal_list" */))
const _651d3865 = () => interopDefault(import('..\\pages\\appraisal\\result.vue' /* webpackChunkName: "pages_appraisal_result" */))
const _3d4474a7 = () => interopDefault(import('..\\pages\\errors\\notfound.vue' /* webpackChunkName: "pages_errors_notfound" */))
const _3291b15b = () => interopDefault(import('..\\pages\\errors\\server.vue' /* webpackChunkName: "pages_errors_server" */))
const _1039a8e3 = () => interopDefault(import('..\\pages\\myCenter\\center.vue' /* webpackChunkName: "pages_myCenter_center" */))
const _382bb861 = () => interopDefault(import('..\\pages\\tuodao\\td.vue' /* webpackChunkName: "pages_tuodao_td" */))
const _493233f0 = () => interopDefault(import('..\\pages\\user\\forgetPwd.vue' /* webpackChunkName: "pages_user_forgetPwd" */))
const _6b5a8a3e = () => interopDefault(import('..\\pages\\user\\login.vue' /* webpackChunkName: "pages_user_login" */))
const _ceb98368 = () => interopDefault(import('..\\pages\\user\\loginPwd.vue' /* webpackChunkName: "pages_user_loginPwd" */))
const _4fb2665b = () => interopDefault(import('..\\pages\\user\\register.vue' /* webpackChunkName: "pages_user_register" */))
const _2e41f71f = () => interopDefault(import('..\\pages\\user\\registerAgreement.vue' /* webpackChunkName: "pages_user_registerAgreement" */))
const _ea58d450 = () => interopDefault(import('..\\pages\\user\\registerResult.vue' /* webpackChunkName: "pages_user_registerResult" */))
const _77810ae8 = () => interopDefault(import('..\\pages\\xwDeposit\\deposit.vue' /* webpackChunkName: "pages_xwDeposit_deposit" */))
const _0dfc911f = () => interopDefault(import('..\\pages\\xwDeposit\\result.vue' /* webpackChunkName: "pages_xwDeposit_result" */))
const _6261b741 = () => interopDefault(import('..\\pages\\xwDeposit\\transit.vue' /* webpackChunkName: "pages_xwDeposit_transit" */))
const _f90b0ec4 = () => interopDefault(import('..\\pages\\home\\inform\\inform.vue' /* webpackChunkName: "pages_home_inform_inform" */))
const _5846b6cc = () => interopDefault(import('..\\pages\\home\\inviteFriend\\inviteFriend.vue' /* webpackChunkName: "pages_home_inviteFriend_inviteFriend" */))
const _7617daa8 = () => interopDefault(import('..\\pages\\home\\newComer\\newComer.vue' /* webpackChunkName: "pages_home_newComer_newComer" */))
const _3f02f3b4 = () => interopDefault(import('..\\pages\\home\\notice\\list-dynamic.vue' /* webpackChunkName: "pages_home_notice_list-dynamic" */))
const _e4f5f51a = () => interopDefault(import('..\\pages\\home\\notice\\list-notice.vue' /* webpackChunkName: "pages_home_notice_list-notice" */))
const _335cad08 = () => interopDefault(import('..\\pages\\home\\notice\\notice.vue' /* webpackChunkName: "pages_home_notice_notice" */))
const _38894140 = () => interopDefault(import('..\\pages\\myCenter\\bond\\myBond.vue' /* webpackChunkName: "pages_myCenter_bond_myBond" */))
const _6df608da = () => interopDefault(import('..\\pages\\myCenter\\coupon\\coupon.vue' /* webpackChunkName: "pages_myCenter_coupon_coupon" */))
const _2d58f3dc = () => interopDefault(import('..\\pages\\myCenter\\discount\\myDiscount.vue' /* webpackChunkName: "pages_myCenter_discount_myDiscount" */))
const _ab816c74 = () => interopDefault(import('..\\pages\\myCenter\\fund\\cash.vue' /* webpackChunkName: "pages_myCenter_fund_cash" */))
const _a35735fe = () => interopDefault(import('..\\pages\\myCenter\\fund\\cashExplain.vue' /* webpackChunkName: "pages_myCenter_fund_cashExplain" */))
const _5d086737 = () => interopDefault(import('..\\pages\\myCenter\\fund\\cashRecord.vue' /* webpackChunkName: "pages_myCenter_fund_cashRecord" */))
const _0f24fd03 = () => interopDefault(import('..\\pages\\myCenter\\fund\\cashResult.vue' /* webpackChunkName: "pages_myCenter_fund_cashResult" */))
const _6ec31c27 = () => interopDefault(import('..\\pages\\myCenter\\fund\\rachargeRecord.vue' /* webpackChunkName: "pages_myCenter_fund_rachargeRecord" */))
const _6999848c = () => interopDefault(import('..\\pages\\myCenter\\fund\\recharge.vue' /* webpackChunkName: "pages_myCenter_fund_recharge" */))
const _638729f7 = () => interopDefault(import('..\\pages\\myCenter\\fund\\rechargeResult.vue' /* webpackChunkName: "pages_myCenter_fund_rechargeResult" */))
const _b173cdc6 = () => interopDefault(import('..\\pages\\myCenter\\invest\\creditorList.vue' /* webpackChunkName: "pages_myCenter_invest_creditorList" */))
const _7e9aa2f8 = () => interopDefault(import('..\\pages\\myCenter\\invest\\myInvest.vue' /* webpackChunkName: "pages_myCenter_invest_myInvest" */))
const _950bfcb2 = () => interopDefault(import('..\\pages\\myCenter\\invest\\scatterDetails.vue' /* webpackChunkName: "pages_myCenter_invest_scatterDetails" */))
const _d949dfea = () => interopDefault(import('..\\pages\\myCenter\\invest\\siftDetails.vue' /* webpackChunkName: "pages_myCenter_invest_siftDetails" */))
const _8320bb44 = () => interopDefault(import('..\\pages\\myCenter\\invite\\inviteList.vue' /* webpackChunkName: "pages_myCenter_invite_inviteList" */))
const _36116291 = () => interopDefault(import('..\\pages\\myCenter\\invite\\inviteRecord.vue' /* webpackChunkName: "pages_myCenter_invite_inviteRecord" */))
const _0607ba98 = () => interopDefault(import('..\\pages\\myCenter\\invite\\onList.vue' /* webpackChunkName: "pages_myCenter_invite_onList" */))
const _3418079f = () => interopDefault(import('..\\pages\\myCenter\\invite\\yetList.vue' /* webpackChunkName: "pages_myCenter_invite_yetList" */))
const _719305c2 = () => interopDefault(import('..\\pages\\myCenter\\member\\member.vue' /* webpackChunkName: "pages_myCenter_member_member" */))
const _78705a3c = () => interopDefault(import('..\\pages\\myCenter\\record\\moneyRecord.vue' /* webpackChunkName: "pages_myCenter_record_moneyRecord" */))
const _27756ff9 = () => interopDefault(import('..\\pages\\myCenter\\set\\about.vue' /* webpackChunkName: "pages_myCenter_set_about" */))
const _1b45eabf = () => interopDefault(import('..\\pages\\myCenter\\set\\setPwd.vue' /* webpackChunkName: "pages_myCenter_set_setPwd" */))
const _38062ff1 = () => interopDefault(import('..\\pages\\myCenter\\set\\ucAutonym.vue' /* webpackChunkName: "pages_myCenter_set_ucAutonym" */))
const _403343e0 = () => interopDefault(import('..\\pages\\myCenter\\set\\ucSet.vue' /* webpackChunkName: "pages_myCenter_set_ucSet" */))
const _1b86cb7e = () => interopDefault(import('..\\pages\\myCenter\\set\\xwAccredit.vue' /* webpackChunkName: "pages_myCenter_set_xwAccredit" */))
const _388254bb = () => interopDefault(import('..\\pages\\myCenter\\set\\xwAccreditResult.vue' /* webpackChunkName: "pages_myCenter_set_xwAccreditResult" */))
const _45915246 = () => interopDefault(import('..\\pages\\project\\free\\list.vue' /* webpackChunkName: "pages_project_free_list" */))
const _1122c852 = () => interopDefault(import('..\\pages\\project\\transfer\\transfer.vue' /* webpackChunkName: "pages_project_transfer_transfer" */))
const _2134b295 = () => interopDefault(import('..\\pages\\home\\inform\\aboutTd\\aboutTd.vue' /* webpackChunkName: "pages_home_inform_aboutTd_aboutTd" */))
const _551b2734 = () => interopDefault(import('..\\pages\\home\\inform\\aboutTd\\bank.vue' /* webpackChunkName: "pages_home_inform_aboutTd_bank" */))
const _5bb35e1e = () => interopDefault(import('..\\pages\\home\\inform\\aboutTd\\board.vue' /* webpackChunkName: "pages_home_inform_aboutTd_board" */))
const _30251245 = () => interopDefault(import('..\\pages\\home\\inform\\aboutTd\\great.vue' /* webpackChunkName: "pages_home_inform_aboutTd_great" */))
const _62f406b4 = () => interopDefault(import('..\\pages\\home\\inform\\aboutTd\\info.vue' /* webpackChunkName: "pages_home_inform_aboutTd_info" */))
const _3f223a6e = () => interopDefault(import('..\\pages\\home\\inform\\aboutTd\\record.vue' /* webpackChunkName: "pages_home_inform_aboutTd_record" */))
const _717f11fa = () => interopDefault(import('..\\pages\\home\\inform\\aboutTd\\shareholder.vue' /* webpackChunkName: "pages_home_inform_aboutTd_shareholder" */))
const _ec4d0a5e = () => interopDefault(import('..\\pages\\home\\inform\\auditReport\\audit-report-2017.vue' /* webpackChunkName: "pages_home_inform_auditReport_audit-report-2017" */))
const _ec30db5c = () => interopDefault(import('..\\pages\\home\\inform\\auditReport\\audit-report-2018.vue' /* webpackChunkName: "pages_home_inform_auditReport_audit-report-2018" */))
const _ae8d9212 = () => interopDefault(import('..\\pages\\home\\inform\\auditReport\\audit-report-2018-2.vue' /* webpackChunkName: "pages_home_inform_auditReport_audit-report-2018-2" */))
const _1075cf2a = () => interopDefault(import('..\\pages\\home\\inform\\auditReport\\audit-report-sign.vue' /* webpackChunkName: "pages_home_inform_auditReport_audit-report-sign" */))
const _1b928d56 = () => interopDefault(import('..\\pages\\home\\inform\\auditReport\\auditReport.vue' /* webpackChunkName: "pages_home_inform_auditReport_auditReport" */))
const _6e2b6747 = () => interopDefault(import('..\\pages\\home\\inform\\knowUs\\knowUs.vue' /* webpackChunkName: "pages_home_inform_knowUs_knowUs" */))
const _bda862a4 = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\law-bl.vue' /* webpackChunkName: "pages_home_inform_lawFile_law-bl" */))
const _ba770f6a = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\law-cj.vue' /* webpackChunkName: "pages_home_inform_lawFile_law-cj" */))
const _b582cc10 = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\law-dx.vue' /* webpackChunkName: "pages_home_inform_lawFile_law-dx" */))
const _b0aab7b8 = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\law-ff.vue' /* webpackChunkName: "pages_home_inform_lawFile_law-ff" */))
const _aeaf6994 = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\law-fx.vue' /* webpackChunkName: "pages_home_inform_lawFile_law-fx" */))
const _ad41067a = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\law-gf.vue' /* webpackChunkName: "pages_home_inform_lawFile_law-gf" */))
const _a33c50c4 = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\law-jd.vue' /* webpackChunkName: "pages_home_inform_lawFile_law-jd" */))
const _9d66955a = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\law-kz.vue' /* webpackChunkName: "pages_home_inform_lawFile_law-kz" */))
const _985622fe = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\law-mj.vue' /* webpackChunkName: "pages_home_inform_lawFile_law-mj" */))
const _8de0b140 = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\law-pl.vue' /* webpackChunkName: "pages_home_inform_lawFile_law-pl" */))
const _83a39d86 = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\law-sl.vue' /* webpackChunkName: "pages_home_inform_lawFile_law-sl" */))
const _7140f338 = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\law-xx.vue' /* webpackChunkName: "pages_home_inform_lawFile_law-xx" */))
const _9b7fcc10 = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\law-zjcg.vue' /* webpackChunkName: "pages_home_inform_lawFile_law-zjcg" */))
const _97c18dcc = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\law-zjdj.vue' /* webpackChunkName: "pages_home_inform_lawFile_law-zjdj" */))
const _1e7d5fb5 = () => interopDefault(import('..\\pages\\home\\inform\\lawFile\\lawFile.vue' /* webpackChunkName: "pages_home_inform_lawFile_lawFile" */))
const _490338fb = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2016.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2016" */))
const _4cbff5a2 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2016-q1.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2016-q1" */))
const _4cce0d23 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2016-q2.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2016-q2" */))
const _4cdc24a4 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2016-q3.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2016-q3" */))
const _4cea3c25 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2016-q4.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2016-q4" */))
const _4911507c = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2017.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2017" */))
const _0a9386e3 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2017-m07.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2017-m07" */))
const _0aa19e64 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2017-m08.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2017-m08" */))
const _0be5bafb = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2017-m10.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2017-m10" */))
const _0bf3d27c = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2017-m11.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2017-m11" */))
const _0c01e9fd = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2017-m12.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2017-m12" */))
const _96bdbafe = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2017-q1.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2017-q1" */))
const _96a18bfc = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2017-q2.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2017-q2" */))
const _96855cfa = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2017-q3.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2017-q3" */))
const _c2f92e44 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2018-m01.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2018-m01" */))
const _c2dcff42 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2018-m02.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2018-m02" */))
const _c2c0d040 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2018-m03.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2018-m03" */))
const _c2a4a13e = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2018-m04.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2018-m04" */))
const _c288723c = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2018-m05.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2018-m05" */))
const _c26c433a = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2018-m06.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2018-m06" */))
const _c2501438 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2018-m07.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2018-m07" */))
const _c233e536 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2018-m08.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2018-m08" */))
const _c217b634 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2018-m09.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2018-m09" */))
const _bfabac08 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2018-m10.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2018-m10" */))
const _bf8f7d06 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2018-m11.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2018-m11" */))
const _bf734e04 = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\oper-2018-m12.vue' /* webpackChunkName: "pages_home_inform_operReport_oper-2018-m12" */))
const _3c65270e = () => interopDefault(import('..\\pages\\home\\inform\\operReport\\operReport.vue' /* webpackChunkName: "pages_home_inform_operReport_operReport" */))
const _252969bb = () => interopDefault(import('..\\pages\\home\\inform\\platfromData\\platfromData.vue' /* webpackChunkName: "pages_home_inform_platfromData_platfromData" */))
const _d00a6146 = () => interopDefault(import('..\\pages\\home\\inform\\riskManage\\riskManage.vue' /* webpackChunkName: "pages_home_inform_riskManage_riskManage" */))
const _266a114c = () => interopDefault(import('..\\pages\\myCenter\\discount\\src\\interest-list.vue' /* webpackChunkName: "pages_myCenter_discount_src_interest-list" */))
const _34ca9442 = () => interopDefault(import('..\\pages\\myCenter\\discount\\src\\voucher-list.vue' /* webpackChunkName: "pages_myCenter_discount_src_voucher-list" */))
const _43a01cc0 = () => interopDefault(import('..\\pages\\myCenter\\invest\\src\\list-scatter.vue' /* webpackChunkName: "pages_myCenter_invest_src_list-scatter" */))
const _641fa83c = () => interopDefault(import('..\\pages\\myCenter\\invest\\src\\list-scatter-on.vue' /* webpackChunkName: "pages_myCenter_invest_src_list-scatter-on" */))
const _2531cadb = () => interopDefault(import('..\\pages\\myCenter\\invest\\src\\list-scatter-yet.vue' /* webpackChunkName: "pages_myCenter_invest_src_list-scatter-yet" */))
const _b6fdd7dc = () => interopDefault(import('..\\pages\\myCenter\\invest\\src\\list-sift.vue' /* webpackChunkName: "pages_myCenter_invest_src_list-sift" */))
const _47ac97aa = () => interopDefault(import('..\\pages\\myCenter\\invest\\src\\list-sift-on.vue' /* webpackChunkName: "pages_myCenter_invest_src_list-sift-on" */))
const _997a6da6 = () => interopDefault(import('..\\pages\\myCenter\\invest\\src\\list-sift-yet.vue' /* webpackChunkName: "pages_myCenter_invest_src_list-sift-yet" */))
const _2208b512 = () => interopDefault(import('..\\pages\\project\\free\\details\\investAdd.vue' /* webpackChunkName: "pages_project_free_details_investAdd" */))
const _465572a1 = () => interopDefault(import('..\\pages\\project\\free\\details\\scatterResult.vue' /* webpackChunkName: "pages_project_free_details_scatterResult" */))
const _389feaab = () => interopDefault(import('..\\pages\\project\\free\\details\\siftResult.vue' /* webpackChunkName: "pages_project_free_details_siftResult" */))
const _02e2568a = () => interopDefault(import('..\\pages\\home\\inform\\aboutTd\\src\\big-img.vue' /* webpackChunkName: "pages_home_inform_aboutTd_src_big-img" */))
const _5d4e782b = () => interopDefault(import('..\\pages\\home\\inform\\aboutTd\\src\\certificate.vue' /* webpackChunkName: "pages_home_inform_aboutTd_src_certificate" */))
const _402c4c12 = () => interopDefault(import('..\\pages\\home\\inform\\aboutTd\\src\\framework.vue' /* webpackChunkName: "pages_home_inform_aboutTd_src_framework" */))
const _ba2f6998 = () => interopDefault(import('..\\pages\\home\\inform\\aboutTd\\src\\personnel.vue' /* webpackChunkName: "pages_home_inform_aboutTd_src_personnel" */))
const _3d9605cc = () => interopDefault(import('..\\pages\\home\\inform\\aboutTd\\src\\signature.vue' /* webpackChunkName: "pages_home_inform_aboutTd_src_signature" */))
const _93b15f46 = () => interopDefault(import('..\\pages\\home\\inform\\aboutTd\\src\\terraces.vue' /* webpackChunkName: "pages_home_inform_aboutTd_src_terraces" */))
const _f12c1a16 = () => interopDefault(import('..\\pages\\home\\inform\\platfromData\\src\\broadcast.vue' /* webpackChunkName: "pages_home_inform_platfromData_src_broadcast" */))
const _b6a73444 = () => interopDefault(import('..\\pages\\home\\inform\\platfromData\\src\\collect.vue' /* webpackChunkName: "pages_home_inform_platfromData_src_collect" */))
const _85e0aa14 = () => interopDefault(import('..\\pages\\home\\inform\\platfromData\\src\\details.vue' /* webpackChunkName: "pages_home_inform_platfromData_src_details" */))
const _c51dfd9a = () => interopDefault(import('..\\pages\\project\\free\\details\\add\\discount-list.vue' /* webpackChunkName: "pages_project_free_details_add_discount-list" */))
const _53054f82 = () => interopDefault(import('..\\pages\\project\\free\\details\\add\\list-interest.vue' /* webpackChunkName: "pages_project_free_details_add_list-interest" */))
const _5af34786 = () => interopDefault(import('..\\pages\\project\\free\\details\\add\\list-voucher.vue' /* webpackChunkName: "pages_project_free_details_add_list-voucher" */))
const _a9775410 = () => interopDefault(import('..\\pages\\project\\free\\details\\scatterDetails\\big-img.vue' /* webpackChunkName: "pages_project_free_details_scatterDetails_big-img" */))
const _43549cc6 = () => interopDefault(import('..\\pages\\project\\free\\details\\scatterDetails\\details1.vue' /* webpackChunkName: "pages_project_free_details_scatterDetails_details1" */))
const _43386dc4 = () => interopDefault(import('..\\pages\\project\\free\\details\\scatterDetails\\details2.vue' /* webpackChunkName: "pages_project_free_details_scatterDetails_details2" */))
const _431c3ec2 = () => interopDefault(import('..\\pages\\project\\free\\details\\scatterDetails\\details3.vue' /* webpackChunkName: "pages_project_free_details_scatterDetails_details3" */))
const _78c741cf = () => interopDefault(import('..\\pages\\project\\free\\details\\scatterDetails\\indexs.vue' /* webpackChunkName: "pages_project_free_details_scatterDetails_indexs" */))
const _01061a35 = () => interopDefault(import('..\\pages\\project\\free\\details\\scatterDetails\\scatter-details.vue' /* webpackChunkName: "pages_project_free_details_scatterDetails_scatter-details" */))
const _705ee1bb = () => interopDefault(import('..\\pages\\project\\free\\details\\scatterDetails\\scatter-details-next.vue' /* webpackChunkName: "pages_project_free_details_scatterDetails_scatter-details-next" */))
const _0c40af53 = () => interopDefault(import('..\\pages\\project\\free\\details\\siftDetails\\details1.vue' /* webpackChunkName: "pages_project_free_details_siftDetails_details1" */))
const _0c4ec6d4 = () => interopDefault(import('..\\pages\\project\\free\\details\\siftDetails\\details2.vue' /* webpackChunkName: "pages_project_free_details_siftDetails_details2" */))
const _0c5cde55 = () => interopDefault(import('..\\pages\\project\\free\\details\\siftDetails\\details3.vue' /* webpackChunkName: "pages_project_free_details_siftDetails_details3" */))
const _71a23505 = () => interopDefault(import('..\\pages\\project\\free\\details\\siftDetails\\indexs.vue' /* webpackChunkName: "pages_project_free_details_siftDetails_indexs" */))
const _7c3cbd3d = () => interopDefault(import('..\\pages\\project\\free\\details\\siftDetails\\sift-details.vue' /* webpackChunkName: "pages_project_free_details_siftDetails_sift-details" */))
const _8b06389a = () => interopDefault(import('..\\pages\\project\\free\\details\\siftDetails\\sift-details-next.vue' /* webpackChunkName: "pages_project_free_details_siftDetails_sift-details-next" */))
const _dbbebf96 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected
  if (to.matched.length < 2) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some(r => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise((resolve) => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}

export function createRouter() {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,

    routes: [{
      path: "/api",
      component: _f5a7c09c,
      name: "api"
    }, {
      path: "/project",
      component: _c3b84e74,
      name: "project"
    }, {
      path: "/appraisal/explain",
      component: _176395df,
      name: "appraisal-explain"
    }, {
      path: "/appraisal/indexs",
      component: _96723fae,
      name: "appraisal-indexs"
    }, {
      path: "/appraisal/list",
      component: _de817734,
      name: "appraisal-list"
    }, {
      path: "/appraisal/result",
      component: _651d3865,
      name: "appraisal-result"
    }, {
      path: "/errors/notfound",
      component: _3d4474a7,
      name: "errors-notfound"
    }, {
      path: "/errors/server",
      component: _3291b15b,
      name: "errors-server"
    }, {
      path: "/myCenter/center",
      component: _1039a8e3,
      name: "myCenter-center"
    }, {
      path: "/tuodao/td",
      component: _382bb861,
      name: "tuodao-td"
    }, {
      path: "/user/forgetPwd",
      component: _493233f0,
      name: "user-forgetPwd"
    }, {
      path: "/user/login",
      component: _6b5a8a3e,
      name: "user-login"
    }, {
      path: "/user/loginPwd",
      component: _ceb98368,
      name: "user-loginPwd"
    }, {
      path: "/user/register",
      component: _4fb2665b,
      name: "user-register"
    }, {
      path: "/user/registerAgreement",
      component: _2e41f71f,
      name: "user-registerAgreement"
    }, {
      path: "/user/registerResult",
      component: _ea58d450,
      name: "user-registerResult"
    }, {
      path: "/xwDeposit/deposit",
      component: _77810ae8,
      name: "xwDeposit-deposit"
    }, {
      path: "/xwDeposit/result",
      component: _0dfc911f,
      name: "xwDeposit-result"
    }, {
      path: "/xwDeposit/transit",
      component: _6261b741,
      name: "xwDeposit-transit"
    }, {
      path: "/home/inform/inform",
      component: _f90b0ec4,
      name: "home-inform-inform"
    }, {
      path: "/home/inviteFriend/inviteFriend",
      component: _5846b6cc,
      name: "home-inviteFriend-inviteFriend"
    }, {
      path: "/home/newComer/newComer",
      component: _7617daa8,
      name: "home-newComer-newComer"
    }, {
      path: "/home/notice/list-dynamic",
      component: _3f02f3b4,
      name: "home-notice-list-dynamic"
    }, {
      path: "/home/notice/list-notice",
      component: _e4f5f51a,
      name: "home-notice-list-notice"
    }, {
      path: "/home/notice/notice",
      component: _335cad08,
      name: "home-notice-notice"
    }, {
      path: "/myCenter/bond/myBond",
      component: _38894140,
      name: "myCenter-bond-myBond"
    }, {
      path: "/myCenter/coupon/coupon",
      component: _6df608da,
      name: "myCenter-coupon-coupon"
    }, {
      path: "/myCenter/discount/myDiscount",
      component: _2d58f3dc,
      name: "myCenter-discount-myDiscount"
    }, {
      path: "/myCenter/fund/cash",
      component: _ab816c74,
      name: "myCenter-fund-cash"
    }, {
      path: "/myCenter/fund/cashExplain",
      component: _a35735fe,
      name: "myCenter-fund-cashExplain"
    }, {
      path: "/myCenter/fund/cashRecord",
      component: _5d086737,
      name: "myCenter-fund-cashRecord"
    }, {
      path: "/myCenter/fund/cashResult",
      component: _0f24fd03,
      name: "myCenter-fund-cashResult"
    }, {
      path: "/myCenter/fund/rachargeRecord",
      component: _6ec31c27,
      name: "myCenter-fund-rachargeRecord"
    }, {
      path: "/myCenter/fund/recharge",
      component: _6999848c,
      name: "myCenter-fund-recharge"
    }, {
      path: "/myCenter/fund/rechargeResult",
      component: _638729f7,
      name: "myCenter-fund-rechargeResult"
    }, {
      path: "/myCenter/invest/creditorList",
      component: _b173cdc6,
      name: "myCenter-invest-creditorList"
    }, {
      path: "/myCenter/invest/myInvest",
      component: _7e9aa2f8,
      name: "myCenter-invest-myInvest"
    }, {
      path: "/myCenter/invest/scatterDetails",
      component: _950bfcb2,
      name: "myCenter-invest-scatterDetails"
    }, {
      path: "/myCenter/invest/siftDetails",
      component: _d949dfea,
      name: "myCenter-invest-siftDetails"
    }, {
      path: "/myCenter/invite/inviteList",
      component: _8320bb44,
      name: "myCenter-invite-inviteList"
    }, {
      path: "/myCenter/invite/inviteRecord",
      component: _36116291,
      name: "myCenter-invite-inviteRecord"
    }, {
      path: "/myCenter/invite/onList",
      component: _0607ba98,
      name: "myCenter-invite-onList"
    }, {
      path: "/myCenter/invite/yetList",
      component: _3418079f,
      name: "myCenter-invite-yetList"
    }, {
      path: "/myCenter/member/member",
      component: _719305c2,
      name: "myCenter-member-member"
    }, {
      path: "/myCenter/record/moneyRecord",
      component: _78705a3c,
      name: "myCenter-record-moneyRecord"
    }, {
      path: "/myCenter/set/about",
      component: _27756ff9,
      name: "myCenter-set-about"
    }, {
      path: "/myCenter/set/setPwd",
      component: _1b45eabf,
      name: "myCenter-set-setPwd"
    }, {
      path: "/myCenter/set/ucAutonym",
      component: _38062ff1,
      name: "myCenter-set-ucAutonym"
    }, {
      path: "/myCenter/set/ucSet",
      component: _403343e0,
      name: "myCenter-set-ucSet"
    }, {
      path: "/myCenter/set/xwAccredit",
      component: _1b86cb7e,
      name: "myCenter-set-xwAccredit"
    }, {
      path: "/myCenter/set/xwAccreditResult",
      component: _388254bb,
      name: "myCenter-set-xwAccreditResult"
    }, {
      path: "/project/free/list",
      component: _45915246,
      name: "project-free-list"
    }, {
      path: "/project/transfer/transfer",
      component: _1122c852,
      name: "project-transfer-transfer"
    }, {
      path: "/home/inform/aboutTd/aboutTd",
      component: _2134b295,
      name: "home-inform-aboutTd-aboutTd"
    }, {
      path: "/home/inform/aboutTd/bank",
      component: _551b2734,
      name: "home-inform-aboutTd-bank"
    }, {
      path: "/home/inform/aboutTd/board",
      component: _5bb35e1e,
      name: "home-inform-aboutTd-board"
    }, {
      path: "/home/inform/aboutTd/great",
      component: _30251245,
      name: "home-inform-aboutTd-great"
    }, {
      path: "/home/inform/aboutTd/info",
      component: _62f406b4,
      name: "home-inform-aboutTd-info"
    }, {
      path: "/home/inform/aboutTd/record",
      component: _3f223a6e,
      name: "home-inform-aboutTd-record"
    }, {
      path: "/home/inform/aboutTd/shareholder",
      component: _717f11fa,
      name: "home-inform-aboutTd-shareholder"
    }, {
      path: "/home/inform/auditReport/audit-report-2017",
      component: _ec4d0a5e,
      name: "home-inform-auditReport-audit-report-2017"
    }, {
      path: "/home/inform/auditReport/audit-report-2018",
      component: _ec30db5c,
      name: "home-inform-auditReport-audit-report-2018"
    }, {
      path: "/home/inform/auditReport/audit-report-2018-2",
      component: _ae8d9212,
      name: "home-inform-auditReport-audit-report-2018-2"
    }, {
      path: "/home/inform/auditReport/audit-report-sign",
      component: _1075cf2a,
      name: "home-inform-auditReport-audit-report-sign"
    }, {
      path: "/home/inform/auditReport/auditReport",
      component: _1b928d56,
      name: "home-inform-auditReport-auditReport"
    }, {
      path: "/home/inform/knowUs/knowUs",
      component: _6e2b6747,
      name: "home-inform-knowUs-knowUs"
    }, {
      path: "/home/inform/lawFile/law-bl",
      component: _bda862a4,
      name: "home-inform-lawFile-law-bl"
    }, {
      path: "/home/inform/lawFile/law-cj",
      component: _ba770f6a,
      name: "home-inform-lawFile-law-cj"
    }, {
      path: "/home/inform/lawFile/law-dx",
      component: _b582cc10,
      name: "home-inform-lawFile-law-dx"
    }, {
      path: "/home/inform/lawFile/law-ff",
      component: _b0aab7b8,
      name: "home-inform-lawFile-law-ff"
    }, {
      path: "/home/inform/lawFile/law-fx",
      component: _aeaf6994,
      name: "home-inform-lawFile-law-fx"
    }, {
      path: "/home/inform/lawFile/law-gf",
      component: _ad41067a,
      name: "home-inform-lawFile-law-gf"
    }, {
      path: "/home/inform/lawFile/law-jd",
      component: _a33c50c4,
      name: "home-inform-lawFile-law-jd"
    }, {
      path: "/home/inform/lawFile/law-kz",
      component: _9d66955a,
      name: "home-inform-lawFile-law-kz"
    }, {
      path: "/home/inform/lawFile/law-mj",
      component: _985622fe,
      name: "home-inform-lawFile-law-mj"
    }, {
      path: "/home/inform/lawFile/law-pl",
      component: _8de0b140,
      name: "home-inform-lawFile-law-pl"
    }, {
      path: "/home/inform/lawFile/law-sl",
      component: _83a39d86,
      name: "home-inform-lawFile-law-sl"
    }, {
      path: "/home/inform/lawFile/law-xx",
      component: _7140f338,
      name: "home-inform-lawFile-law-xx"
    }, {
      path: "/home/inform/lawFile/law-zjcg",
      component: _9b7fcc10,
      name: "home-inform-lawFile-law-zjcg"
    }, {
      path: "/home/inform/lawFile/law-zjdj",
      component: _97c18dcc,
      name: "home-inform-lawFile-law-zjdj"
    }, {
      path: "/home/inform/lawFile/lawFile",
      component: _1e7d5fb5,
      name: "home-inform-lawFile-lawFile"
    }, {
      path: "/home/inform/operReport/oper-2016",
      component: _490338fb,
      name: "home-inform-operReport-oper-2016"
    }, {
      path: "/home/inform/operReport/oper-2016-q1",
      component: _4cbff5a2,
      name: "home-inform-operReport-oper-2016-q1"
    }, {
      path: "/home/inform/operReport/oper-2016-q2",
      component: _4cce0d23,
      name: "home-inform-operReport-oper-2016-q2"
    }, {
      path: "/home/inform/operReport/oper-2016-q3",
      component: _4cdc24a4,
      name: "home-inform-operReport-oper-2016-q3"
    }, {
      path: "/home/inform/operReport/oper-2016-q4",
      component: _4cea3c25,
      name: "home-inform-operReport-oper-2016-q4"
    }, {
      path: "/home/inform/operReport/oper-2017",
      component: _4911507c,
      name: "home-inform-operReport-oper-2017"
    }, {
      path: "/home/inform/operReport/oper-2017-m07",
      component: _0a9386e3,
      name: "home-inform-operReport-oper-2017-m07"
    }, {
      path: "/home/inform/operReport/oper-2017-m08",
      component: _0aa19e64,
      name: "home-inform-operReport-oper-2017-m08"
    }, {
      path: "/home/inform/operReport/oper-2017-m10",
      component: _0be5bafb,
      name: "home-inform-operReport-oper-2017-m10"
    }, {
      path: "/home/inform/operReport/oper-2017-m11",
      component: _0bf3d27c,
      name: "home-inform-operReport-oper-2017-m11"
    }, {
      path: "/home/inform/operReport/oper-2017-m12",
      component: _0c01e9fd,
      name: "home-inform-operReport-oper-2017-m12"
    }, {
      path: "/home/inform/operReport/oper-2017-q1",
      component: _96bdbafe,
      name: "home-inform-operReport-oper-2017-q1"
    }, {
      path: "/home/inform/operReport/oper-2017-q2",
      component: _96a18bfc,
      name: "home-inform-operReport-oper-2017-q2"
    }, {
      path: "/home/inform/operReport/oper-2017-q3",
      component: _96855cfa,
      name: "home-inform-operReport-oper-2017-q3"
    }, {
      path: "/home/inform/operReport/oper-2018-m01",
      component: _c2f92e44,
      name: "home-inform-operReport-oper-2018-m01"
    }, {
      path: "/home/inform/operReport/oper-2018-m02",
      component: _c2dcff42,
      name: "home-inform-operReport-oper-2018-m02"
    }, {
      path: "/home/inform/operReport/oper-2018-m03",
      component: _c2c0d040,
      name: "home-inform-operReport-oper-2018-m03"
    }, {
      path: "/home/inform/operReport/oper-2018-m04",
      component: _c2a4a13e,
      name: "home-inform-operReport-oper-2018-m04"
    }, {
      path: "/home/inform/operReport/oper-2018-m05",
      component: _c288723c,
      name: "home-inform-operReport-oper-2018-m05"
    }, {
      path: "/home/inform/operReport/oper-2018-m06",
      component: _c26c433a,
      name: "home-inform-operReport-oper-2018-m06"
    }, {
      path: "/home/inform/operReport/oper-2018-m07",
      component: _c2501438,
      name: "home-inform-operReport-oper-2018-m07"
    }, {
      path: "/home/inform/operReport/oper-2018-m08",
      component: _c233e536,
      name: "home-inform-operReport-oper-2018-m08"
    }, {
      path: "/home/inform/operReport/oper-2018-m09",
      component: _c217b634,
      name: "home-inform-operReport-oper-2018-m09"
    }, {
      path: "/home/inform/operReport/oper-2018-m10",
      component: _bfabac08,
      name: "home-inform-operReport-oper-2018-m10"
    }, {
      path: "/home/inform/operReport/oper-2018-m11",
      component: _bf8f7d06,
      name: "home-inform-operReport-oper-2018-m11"
    }, {
      path: "/home/inform/operReport/oper-2018-m12",
      component: _bf734e04,
      name: "home-inform-operReport-oper-2018-m12"
    }, {
      path: "/home/inform/operReport/operReport",
      component: _3c65270e,
      name: "home-inform-operReport-operReport"
    }, {
      path: "/home/inform/platfromData/platfromData",
      component: _252969bb,
      name: "home-inform-platfromData-platfromData"
    }, {
      path: "/home/inform/riskManage/riskManage",
      component: _d00a6146,
      name: "home-inform-riskManage-riskManage"
    }, {
      path: "/myCenter/discount/src/interest-list",
      component: _266a114c,
      name: "myCenter-discount-src-interest-list"
    }, {
      path: "/myCenter/discount/src/voucher-list",
      component: _34ca9442,
      name: "myCenter-discount-src-voucher-list"
    }, {
      path: "/myCenter/invest/src/list-scatter",
      component: _43a01cc0,
      name: "myCenter-invest-src-list-scatter"
    }, {
      path: "/myCenter/invest/src/list-scatter-on",
      component: _641fa83c,
      name: "myCenter-invest-src-list-scatter-on"
    }, {
      path: "/myCenter/invest/src/list-scatter-yet",
      component: _2531cadb,
      name: "myCenter-invest-src-list-scatter-yet"
    }, {
      path: "/myCenter/invest/src/list-sift",
      component: _b6fdd7dc,
      name: "myCenter-invest-src-list-sift"
    }, {
      path: "/myCenter/invest/src/list-sift-on",
      component: _47ac97aa,
      name: "myCenter-invest-src-list-sift-on"
    }, {
      path: "/myCenter/invest/src/list-sift-yet",
      component: _997a6da6,
      name: "myCenter-invest-src-list-sift-yet"
    }, {
      path: "/project/free/details/investAdd",
      component: _2208b512,
      name: "project-free-details-investAdd"
    }, {
      path: "/project/free/details/scatterResult",
      component: _465572a1,
      name: "project-free-details-scatterResult"
    }, {
      path: "/project/free/details/siftResult",
      component: _389feaab,
      name: "project-free-details-siftResult"
    }, {
      path: "/home/inform/aboutTd/src/big-img",
      component: _02e2568a,
      name: "home-inform-aboutTd-src-big-img"
    }, {
      path: "/home/inform/aboutTd/src/certificate",
      component: _5d4e782b,
      name: "home-inform-aboutTd-src-certificate"
    }, {
      path: "/home/inform/aboutTd/src/framework",
      component: _402c4c12,
      name: "home-inform-aboutTd-src-framework"
    }, {
      path: "/home/inform/aboutTd/src/personnel",
      component: _ba2f6998,
      name: "home-inform-aboutTd-src-personnel"
    }, {
      path: "/home/inform/aboutTd/src/signature",
      component: _3d9605cc,
      name: "home-inform-aboutTd-src-signature"
    }, {
      path: "/home/inform/aboutTd/src/terraces",
      component: _93b15f46,
      name: "home-inform-aboutTd-src-terraces"
    }, {
      path: "/home/inform/platfromData/src/broadcast",
      component: _f12c1a16,
      name: "home-inform-platfromData-src-broadcast"
    }, {
      path: "/home/inform/platfromData/src/collect",
      component: _b6a73444,
      name: "home-inform-platfromData-src-collect"
    }, {
      path: "/home/inform/platfromData/src/details",
      component: _85e0aa14,
      name: "home-inform-platfromData-src-details"
    }, {
      path: "/project/free/details/add/discount-list",
      component: _c51dfd9a,
      name: "project-free-details-add-discount-list"
    }, {
      path: "/project/free/details/add/list-interest",
      component: _53054f82,
      name: "project-free-details-add-list-interest"
    }, {
      path: "/project/free/details/add/list-voucher",
      component: _5af34786,
      name: "project-free-details-add-list-voucher"
    }, {
      path: "/project/free/details/scatterDetails/big-img",
      component: _a9775410,
      name: "project-free-details-scatterDetails-big-img"
    }, {
      path: "/project/free/details/scatterDetails/details1",
      component: _43549cc6,
      name: "project-free-details-scatterDetails-details1"
    }, {
      path: "/project/free/details/scatterDetails/details2",
      component: _43386dc4,
      name: "project-free-details-scatterDetails-details2"
    }, {
      path: "/project/free/details/scatterDetails/details3",
      component: _431c3ec2,
      name: "project-free-details-scatterDetails-details3"
    }, {
      path: "/project/free/details/scatterDetails/indexs",
      component: _78c741cf,
      name: "project-free-details-scatterDetails-indexs"
    }, {
      path: "/project/free/details/scatterDetails/scatter-details",
      component: _01061a35,
      name: "project-free-details-scatterDetails-scatter-details"
    }, {
      path: "/project/free/details/scatterDetails/scatter-details-next",
      component: _705ee1bb,
      name: "project-free-details-scatterDetails-scatter-details-next"
    }, {
      path: "/project/free/details/siftDetails/details1",
      component: _0c40af53,
      name: "project-free-details-siftDetails-details1"
    }, {
      path: "/project/free/details/siftDetails/details2",
      component: _0c4ec6d4,
      name: "project-free-details-siftDetails-details2"
    }, {
      path: "/project/free/details/siftDetails/details3",
      component: _0c5cde55,
      name: "project-free-details-siftDetails-details3"
    }, {
      path: "/project/free/details/siftDetails/indexs",
      component: _71a23505,
      name: "project-free-details-siftDetails-indexs"
    }, {
      path: "/project/free/details/siftDetails/sift-details",
      component: _7c3cbd3d,
      name: "project-free-details-siftDetails-sift-details"
    }, {
      path: "/project/free/details/siftDetails/sift-details-next",
      component: _8b06389a,
      name: "project-free-details-siftDetails-sift-details-next"
    }, {
      path: "/",
      component: _dbbebf96,
      name: "index"
    }],

    fallback: false
  })
}
