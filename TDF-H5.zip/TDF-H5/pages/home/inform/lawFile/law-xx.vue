<template>
  <div class="law_xx">
    <td-header title="法律文件"/>
    <p
      align="center"
      style="text-align:center;">
      <b>互联网信息服务管理办法</b><b />
    </p>
    <p
      align="center"
      style="text-align:center;">
      <br>
      <span>（</span>2000年9月25日中华人民共和国国务院令第292号公布 根据2011年1月8日国务院令第588号《国务院关于废止和修改部分行政法规的决定》修订）
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <a name="1"/>&nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第一条</span>
      <span>为了规范互联网信息服务活动，促进互联网信息服务健康有序发展，制定本办法。</span>
      <a name="2"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第二条</span>
      <span>在中华人民共和国境内从事互联网信息服务活动，必须遵守本办法。</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>本办法所称互联网信息服务，是指通过互联网向上网用户提供信息的服务活动。</span>
      <a name="3"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第三条</span>
      <span>互联网信息服务分为经营性和非经营性两类。</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      经营性互联网信息服务，是指通过互联网向上网用户有偿提供信息或者网页制作等服务活动。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>非经营性互联网信息服务，是指通过互联网向上网用户无偿提供具有公开性、共享性信息的服务活动。</span><a name="4"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第四条</span>
      <span>国家对经营性互联网信息服务实行许可制度；对非经营性互联网信息服务实行备案制度。</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>未取得许可或者未履行备案手续的，不得从事互联网信息服务。</span><a name="5"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第五条</span>
      <span>从事新闻、出版、教育、医疗保健、药品和医疗器械等互联网信息服务，依照法律、行政法规以及国家有关规定须经有关主管部门审核同意的，在申请经营许可或者履行备案手续前，应当依法经有关主管部门审核同意。</span><br>
      <a name="6"/>&nbsp;&nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第六条</span>
      <span>从事经营性互联网信息服务，除应当符合《</span><a><u>中华人民共和国电信条例</u></a>》规定的要求外，还应当具备下列条件：
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （一）有业务发展计划及相关技术方案；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （二）有健全的网络与信息安全保障措施，包括网站安全保障措施、信息安全保密管理制度、用户信息安全管理制度；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>（三）服务项目属于本办法第五条规定范围的，已取得有关主管部门同意的文件。</span><a name="7"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第七条</span>
      <span>从事经营性互联网信息服务，应当向省、自治区、直辖市电信管理机构或者国务院信息产业主管部门申请办理互联网信息服务增值电信业务经营许可证（以下简称经营许可证）。</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>省、自治区、直辖市电信管理机构或者国务院信息产业主管部门应当自收到申请之日起</span>60日内审查完毕，作出批准或者不予批准的决定。予以批准的，颁发经营许可证；不予批准的，应当书面通知申请人并说明理由。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>申请人取得经营许可证后，应当持经营许可证向企业登记机关办理登记手续。</span><a name="8"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第八条</span>
      <span>从事非经营性互联网信息服务，应当向省、自治区、直辖市电信管理机构或者国务院信息产业主管部门办理备案手续。办理备案时，应当提交下列材料：</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （一）主办单位和网站负责人的基本情况；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （二）网站网址和服务项目；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （三）服务项目属于本办法第五条规定范围的，已取得有关主管部门的同意文件。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>省、自治区、直辖市电信管理机构对备案材料齐全的，应当予以备案并编号。</span><a name="9"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第九条</span>
      <span>从事互联网信息服务，拟开办电子公告服务的，应当在申请经营性互联网信息服务许可或者办理非经营性互联网信息服务备案时，按照国家有关规定提出专项申请或者专项备案。</span><a name="10"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十条</span>
      <span>省、自治区、直辖市电信管理机构和国务院信息产业主管部门应当公布取得经营许可证或者已履行备案手续的互联网信息服务提供者名单。</span><a name="11"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十一条</span>
      <span>互联网信息服务提供者应当按照经许可或者备案的项目提供服务，不得超出经许可或者备案的项目提供服务。</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      非经营性互联网信息服务提供者不得从事有偿服务。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>互联网信息服务提供者变更服务项目、网站网址等事项的，应当提前</span>30日向原审核、发证或者备案机关办理变更手续。<a name="12"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十二条</span>
      <span>互联网信息服务提供者应当在其网站主页的显著位置标明其经营许可证编号或者备案编号。</span><a name="13"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十三条</span>
      <span>互联网信息服务提供者应当向上网用户提供良好的服务，并保证所提供的信息内容合法。</span><a name="14"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十四条</span>
      <span>从事新闻、出版以及电子公告等服务项目的互联网信息服务提供者，应当记录提供的信息内容及其发布时间、互联网地址或者域名；互联网接入服务提供者应当记录上网用户的上网时间、用户账号、互联网地址或者域名、主叫电话号码等信息。</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>互联网信息服务提供者和互联网接入服务提供者的记录备份应当保存</span>60日，并在国家有关机关依法查询时，予以提供。<a name="15"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十五条</span>
      <span>互联网信息服务提供者不得制作、复制、发布、传播含有下列内容的信息：</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （一）反对<a><u>宪法</u></a>所确定的基本原则的；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （二）危害国家安全，泄露国家秘密，颠覆国家政权，破坏国家统一的；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （三）损害国家荣誉和利益的；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （四）煽动民族仇恨、民族歧视，破坏民族团结的；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （五）破坏国家宗教政策，宣扬邪教和封建迷信的；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （六）散布谣言，扰乱社会秩序，破坏社会稳定的；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （七）散布淫秽、色情、赌博、暴力、凶杀、恐怖或者教唆犯罪的；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （八）侮辱或者诽谤他人，侵害他人合法权益的；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>（九）含有法律、行政法规禁止的其他内容的。</span><a name="16"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十六条</span>
      <span>互联网信息服务提供者发现其网站传输的信息明显属于本办法第十五条所列内容之一的，应当立即停止传输，保存有关记录，并向国家有关机关报告。</span><a name="17"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十七条</span>
      <span>经营性互联网信息服务提供者申请在境内境外上市或者同外商合资、合作，应当事先经国务院信息产业主管部门审查同意；其中，外商投资的比例应当符合有关法律、行政法规的规定。</span><a name="18"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十八条</span>
      <span>国务院信息产业主管部门和省、自治区、直辖市电信管理机构，依法对互联网信息服务实施监督管理。</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>新闻、出版、教育、卫生、药品监督管理、工商行政管理和公安、国家安全等有关主管部门，在各自职责范围内依法对互联网信息内容实施监督管理。</span><a name="19"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十九条</span>
      <span>违反本办法的规定，未取得经营许可证，擅自从事经营性互联网信息服务，或者超出许可的项目提供服务的，由省、自治区、直辖市电信管理机构责令限期改正，有违法所得的，没收违法所得，处违法所得</span>3倍以上5倍以下的罚款；没有违法所得或者违法所得不足5万元的，处10万元以上100万元以下的罚款；情节严重的，责令关闭网站。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>违反本办法的规定，未履行备案手续，擅自从事非经营性互联网信息服务，或者超出备案的项目提供服务的，由省、自治区、直辖市电信管理机构责令限期改正；拒不改正的，责令关闭网站。</span><a name="20"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第二十条</span>
      <span>制作、复制、发布、传播本办法第十五条所列内容之一的信息，构成犯罪的，依法追究刑事责任；尚不构成犯罪的，由公安机关、国家安全机关依照《</span><a><u>中华人民共和国治安管理处罚法</u></a>》、《<a><u>计算机信息网络国际联网安全保护管理办法</u></a><span>》等有关法律、行政法规的规定予以处罚；对经营性互联网信息服务提供者，并由发证机关责令停业整顿直至吊销经营许可证，通知企业登记机关；对非经营性互联网信息服务提供者，并由备案机关责令暂时关闭网站直至关闭网站。</span><a name="21"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第二十一条</span>
      <span>未履行本办法第十四条规定的义务的，由省、自治区、直辖市电信管理机构责令改正；情节严重的，责令停业整顿或者暂时关闭网站。</span><a name="22"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第二十二条</span>
      <span>违反本办法的规定，未在其网站主页上标明其经营许可证编号或者备案编号的，由省、自治区、直辖市电信管理机构责令改正，处</span>5000元以上5万元以下的罚款。<a name="23"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第二十三条</span>
      <span>违反本办法第十六条规定的义务的，由省、自治区、直辖市电信管理机构责令改正；情节严重的，对经营性互联网信息服务提供者，并由发证机关吊销经营许可证，对非经营性互联网信息服务提供者，并由备案机关责令关闭网站。</span><a name="24"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第二十四条</span>
      <span>互联网信息服务提供者在其业务活动中，违反其他法律、法规的，由新闻、出版、教育、卫生、药品监督管理和工商行政管理等有关主管部门依照有关法律、法规的规定处罚。</span><a name="25"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第二十五条</span>
      <span>电信管理机构和其他有关主管部门及其工作人员，玩忽职守、滥用职权、徇私舞弊，疏于对互联网信息服务的监督管理，造成严重后果，构成犯罪的，依法追究刑事责任；尚不构成犯罪的，对直接负责的主管人员和其他直接责任人员依法给予降级、撤职直至开除的行政处分。</span><a name="26"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第二十六条</span>
      <span>在本办法公布前从事互联网信息服务的，应当自本办法公布之日起</span>60日内依照本办法的有关规定补办有关手续。<a name="27"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第二十七条</span>
      <span>本办法自公布之日起施行。</span>
    </p>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '法律文件'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .law_xx
    font-size: $fontsize-small-ss
    padding: 1.02rem 5% 0.2rem
    background-color: #fff
    b
      font-weight: bold
      span
        font-weight: bold
    p
      line-height: 0.36rem
</style>
