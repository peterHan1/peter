<template>
  <div class="law_ff">
    <td-header title="法律文件"/>
    <p
      align="center"
      style="text-align:center;">
      <b>最高人民法院关于非法集资刑事案件性质认定问题的通知</b><b />
    </p>
    <p
      align="center"
      style="text-align:center;">
      <b><span>法〔</span>2011〕262号</b><b />
    </p>
    <p
      align="justify"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:justify;">
      &nbsp;
    </p>
    <p
      align="justify"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:justify;">
      各省、自治区、直辖市高级人民法院，解放军军事法院，新疆吾尔自治区高级人民法院生产建设兵团分院：
    </p>
    <p
      align="justify"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:justify;">
      为依法、准确、及时审理非法集资刑事案件，现就非法集资性质认定的有关问题通知如下：
    </p>
    <p
      align="justify"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:justify;">
      &nbsp;
    </p>
    <p
      align="justify"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:justify;">
      一、行政部门对于非法集资的性质认定，不是非法集资案件进入刑事程序的必经程序。行政部门未对非法集资作出性质认定的，不影响非法集资刑事案件的审判。
    </p>
    <p
      align="justify"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:justify;">
      &nbsp;
    </p>
    <p
      align="justify"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:justify;">
      二、人民法院应当依照刑法和《最高人民法院关于审理非法集资刑事案件具体应用法律若干问题的解释》等有关规定认定案件事实的性质，并认定相关行为是否构成犯罪。
    </p>
    <p
      align="justify"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:justify;">
      &nbsp;
    </p>
    <p
      align="justify"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:justify;">
      三、对于案情复杂、性质认定疑难的案件，人民法院可以在有关部门关于是否符合行业技术标准的行政认定意见的基础上，根据案件事实和法律规定作出性质认定。
    </p>
    <p
      align="justify"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:justify;">
      &nbsp;
    </p>
    <p
      align="justify"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:justify;">
      四、非法集资刑事案件的审判工作涉及领域广、专业性强，人民法院在审理此类案件当中要注意加强与有关行政主（监）管部门以及公安机关、人民检察院的配合。审判工作中遇到重大问题难以解决的，请及时报告最高人民法院。
    </p>
    <p
      align="justify"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:justify;">
      &nbsp;
    </p>
    <p
      align="right"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:right;">
      二〇一一年八月十八日
    </p>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '法律文件'
  },
  data() {
    return {}
  },
  mounted() {
    document.getElementsByTagName('body')[0].style.backgroundColor = '#fff'
  }
}
</script>
<style lang="stylus" scoped>
  .law_ff
    font-size: $fontsize-small-ss
    padding: 1.02rem 5% 0.2rem
    background-color: #fff
    p
      line-height:0.36rem
      b
        font-weight: bold
        span
          font-weight: bold
</style>
