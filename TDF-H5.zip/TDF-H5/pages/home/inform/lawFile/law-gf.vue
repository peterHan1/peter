<template>
  <div class="law_gf">
    <td-header title="法律文件"/>
    <p
      align="center"
      style="text-align:center;">
      <b><span>工业和信息化部令（第</span>20号）</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>《规范互联网信息服务市场秩序若干规定》已经</span>2011年12月7日中华人民共和国工业和信息化部第22次部务会议审议通过，现予公布，自2012年3月15日起施行。
    </p>
    <p
      align="right"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:right;">
      部长：苗圩<br>
      二〇一一年十二月二十九日
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p
      align="center"
      style="text-align:center;">
      <b>规范互联网信息服务市场秩序若干规定</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <a name="1"/>&nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第一条</span>
      <span>为了规范互联网信息服务市场秩序，保护互联网信息服务提供者和用户的合法权益，促进互联网行业的健康发展，根据《</span><a><u>中华人民共和国电信条例</u></a>》、《<a><u>互联网信息服务管理办法</u></a>》等法律、行政法规的规定，制定本规定。<br>
      <a name="2"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第二条</span>
      <span>在中华人民共和国境内从事互联网信息服务及与互联网信息服务有关的活动，应当遵守本规定。</span><br>
      <a name="3"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第三条</span>
      <span>工业和信息化部和各省、自治区、直辖市通信管理局（以下统称</span>“电信管理机构”）依法对互联网信息服务活动实施监督管理。<br>
      <a name="4"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第四条</span>
      <span>互联网信息服务提供者应当遵循平等、自愿、公平、诚信的原则提供服务。</span><br>
      <a name="5"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第五条</span>
      <span>互联网信息服务提供者不得实施下列侵犯其他互联网信息服务提供者合法权益的行为：</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>（一）恶意干扰用户终端上其他互联网信息服务提供者的服务，或者恶意干扰与互联网信息服务相关的软件等产品（</span>“与互联网信息服务相关的软件等产品”以下简称“产品”）的下载、安装、运行和升级；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （二）捏造、散布虚假事实损害其他互联网信息服务提供者的合法权益，或者诋毁其他互联网信息服务提供者的服务或者产品；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （三）恶意对其他互联网信息服务提供者的服务或者产品实施不兼容；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （四）欺骗、误导或者强迫用户使用或者不使用其他互联网信息服务提供者的服务或者产品；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （五）恶意修改或者欺骗、误导、强迫用户修改其他互联网信息服务提供者的服务或者产品参数；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （六）其他违反国家法律规定，侵犯其他互联网信息服务提供者合法权益的行为。<br>
      <a name="6"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第六条</span>
      <span>对互联网信息服务提供者的服务或者产品进行评测，应当客观公正。</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      评测方公开或者向用户提供评测结果的，应当同时提供评测实施者、评测方法、数据来源、用户原始评价、评测手段和评测环境等与评测活动相关的信息。评测结果应当真实准确，与评测活动相关的信息应当完整全面。被评测的服务或者产品与评测方的服务或者产品相同或者功能类似的，评测结果中不得含有评测方的主观评价。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      被评测方对评测结果有异议的，可以自行或者委托第三方就评测结果进行再评测，评测方应当予以配合。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      评测方不得利用评测结果，欺骗、误导、强迫用户对被评测方的服务或者产品作出处置。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      本规定所称评测，是指提供平台供用户评价，或者以其他方式对互联网信息服务或者产品的性能等进行评价和测试。<br>
      <a name="7"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第七条</span>
      <span>互联网信息服务提供者不得实施下列侵犯用户合法权益的行为：</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （一）无正当理由拒绝、拖延或者中止向用户提供互联网信息服务或者产品；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （二）无正当理由限定用户使用或者不使用其指定的互联网信息服务或者产品；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （三）以欺骗、误导或者强迫等方式向用户提供互联网信息服务或者产品；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （四）提供的互联网信息服务或者产品与其向用户所作的宣传或者承诺不符；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （五）擅自改变服务协议或者业务规程，降低服务质量或者加重用户责任；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （六）与其他互联网信息服务提供者的服务或者产品不兼容时，未主动向用户提示和说明；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （七）未经提示并由用户主动选择同意，修改用户浏览器配置或者其他设置；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （八）其他违反国家法律规定，侵犯用户合法权益的行为。<br>
      <a name="8"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第八条</span>
      <span>互联网信息服务提供者在用户终端上进行软件下载、安装、运行、升级、卸载等操作的，应当提供明确、完整的软件功能等信息，并事先征得用户同意。</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      互联网信息服务提供者不得实施下列行为：
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （一）欺骗、误导或者强迫用户下载、安装、运行、升级、卸载软件；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （二）未提供与软件安装方式同等或者更便捷的卸载方式；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （三）在未受其他软件影响和人为破坏的情况下，未经用户主动选择同意，软件卸载后有可执行代码或者其他不必要的文件驻留在用户终端。<br>
      <a name="9"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第九条</span>
      <span>互联网信息服务终端软件捆绑其他软件的，应当以显著的方式提示用户，由用户主动选择是否安装或者使用，并提供独立的卸载或者关闭方式，不得附加不合理条件。</span><br>
      <a name="10"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十条</span>
      <span>互联网信息服务提供者在用户终端弹出广告或者其他与终端软件功能无关的信息窗口的，应当以显著的方式向用户提供关闭或者退出窗口的功能标识。</span><br>
      <a name="11"/>&nbsp;&nbsp;<span>第十一条</span>
      <span>未经用户同意，互联网信息服务提供者不得收集与用户相关、能够单独或者与其他信息结合识别用户的信息（以下简称</span>“用户个人信息”），不得将用户个人信息提供给他人，但是法律、行政法规另有规定的除外。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      互联网信息服务提供者经用户同意收集用户个人信息的，应当明确告知用户收集和处理用户个人信息的方式、内容和用途，不得收集其提供服务所必需以外的信息，不得将用户个人信息用于其提供服务之外的目的。<br>
      <a name="12"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十二条</span>
      <span>互联网信息服务提供者应当妥善保管用户个人信息；保管的用户个人信息泄露或者可能泄露时，应当立即采取补救措施；造成或者可能造成严重后果的，应当立即向准予其互联网信息服务许可或者备案的电信管理机构报告，并配合相关部门进行的调查处理。</span><br>
      <a name="13"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十三条</span>
      <span>互联网信息服务提供者应当加强系统安全防护，依法维护用户上载信息的安全，保障用户对上载信息的使用、修改和删除。</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      互联网信息服务提供者不得有下列行为：
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （一）无正当理由擅自修改或者删除用户上载信息；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （二）未经用户同意，向他人提供用户上载信息，但是法律、行政法规另有规定的除外；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （三）擅自或者假借用户名义转移用户上载信息，或者欺骗、误导、强迫用户转移其上载信息；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （四）其他危害用户上载信息安全的行为。<br>
      <a name="14"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十四条</span>
      <span>互联网信息服务提供者应当以显著的方式公布有效联系方式，接受用户及其他互联网信息服务提供者的投诉，并自接到投诉之日起十五日内作出答复。</span><br>
      <a name="15"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十五条</span>
      <span>互联网信息服务提供者认为其他互联网信息服务提供者实施违反本规定的行为，侵犯其合法权益并对用户权益造成或者可能造成重大影响的，应当立即向准予该其他互联网信息服务提供者互联网信息服务许可或者备案的电信管理机构报告。</span>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      电信管理机构应当对报告或者发现的可能违反本规定的行为的影响进行评估；影响特别重大的，相关省、自治区、直辖市通信管理局应当向工业和信息化部报告。电信管理机构在依据本规定作出处理决定前，可以要求互联网信息服务提供者暂停有关行为，互联网信息服务提供者应当执行。<br>
      <a name="16"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十六条</span>
      <span>互联网信息服务提供者违反本规定第五条、第七条或者第十三条的规定，由电信管理机构依据职权责令改正，处以警告，可以并处一万元以上三万元以下的罚款，向社会公告；其中，《</span><a><u>中华人民共和国电信条例</u></a>》或者《<a><u>互联网信息服务管理办法</u></a>》规定法律责任的，依照其规定处理。<br>
      <a name="17"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十七条</span>
      <span>评测方违反本规定第六条的规定的，由电信管理机构依据职权处以警告，可以并处一万元以上三万元以下的罚款，向社会公告。</span><br>
      <a name="18"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十八条</span>
      <span>互联网信息服务提供者违反本规定第八条、第九条、第十条、第十一条、第十二条或者第十四条的规定的，由电信管理机构依据职权处以警告，可以并处一万元以上三万元以下的罚款，向社会公告。</span><br>
      <a name="19"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第十九条</span>
      <span>互联网信息服务提供者违反本规定第十五条规定，不执行电信管理机构暂停有关行为的要求的，由电信管理机构依据职权处以警告，向社会公告。</span><br>
      <a name="20"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第二十条</span>
      <span>互联网信息服务提供者违反其他法律、行政法规规定的，依照其规定处理。</span><br>
      <a name="21"/>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>第二十一条</span>
      <span>本规定自</span>2012年3月15日起施行。
    </p>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '法律文件'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .law_gf
    font-size: $fontsize-small-ss
    padding: 1.02rem 5% 0.2rem
    background-color: #fff
    p
      line-height:0.36rem
      b
        font-weight: bold
        span
          font-weight: bold
</style>
