<template>
  <div class="law_jd">
    <td-header title="法律文件"/>
    <p
      align="center"
      style="margin-left:0.0000pt;text-indent:0.0000pt;text-align:center;">
      <b>网络借贷信息中介机构业务活动管理暂行办法</b><b />
    </p>
    <p
      align="center"
      style="margin-left:0.0000pt;text-indent:24.0000pt;text-align:center;">
      <b>&nbsp;</b>
    </p>
    <p
      align="center"
      style="text-align:center;">
      <b>第一章&emsp;总&emsp;则</b><b />
    </p>
    <p
      align="center"
      style="text-align:center;">
      <b>&nbsp;</b>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第一条</b>&emsp;为规范网络借贷信息中介机构业务活动，保护出借人、借款人、网络借贷信息中介机构及相关当事人合法权益，促进网络借贷行业健康发展，更好满足中小微企业和个人投融资需求，根据《关于促进互联网金融健康发展的指导意见》提出的总体要求和监管原则，依据《中华人民共和国民法通则》、《中华人民共和国公司法》、《中华人民共和国合同法》等法律法规，制定本办法。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第二条</b>&emsp;在中国境内从事网络借贷信息中介业务活动，适用本办法，法律法规另有规定的除外。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      本办法所称网络借贷是指个体和个体之间通过互联网平台实现的直接借贷。个体包含自然人、法人及其他组织。网络借贷信息中介机构是指依法设立，专门从事网络借贷信息中介业务活动的金融信息中介公司。该类机构以互联网为主要渠道，为借款人与出借人（即贷款人）实现直接借贷提供信息搜集、信息公布、资信评估、信息交互、借贷撮合等服务。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      本办法所称地方金融监管部门是指各省级人民政府承担地方金融监管职责的部门。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第三条</b>&emsp;网络借贷信息中介机构按照依法、诚信、自愿、公平的原则为借款人和出借人提供信息服务，维护出借人与借款人合法权益，不得提供增信服务，不得直接或间接归集资金，不得非法集资，不得损害国家利益和社会公共利益。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      借款人与出借人遵循借贷自愿、诚实守信、责任自负、风险自担的原则承担借贷风险。网络借贷信息中介机构承担客观、真实、全面、及时进行信息披露的责任，不承担借贷违约风险。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第四条</b><span>&emsp;按照《关于促进互联网金融健康发展的指导意见》中</span>“鼓励创新、防范风险、趋利避害、健康发展”的总体要求和“依法监管、适度监管、分类监管、协同监管、创新监管”的监管原则，落实各方管理责任。国务院银行业监督管理机构及其派出机构负责制定网络借贷信息中介机构业务活动监督管理制度，并实施行为监管。各省级人民政府负责本辖区网络借贷信息中介机构的机构监管。工业和信息化部负责对网络借贷信息中介机构业务活动涉及的电信业务进行监管。公安部牵头负责对网络借贷信息中介机构的互联网服务进行安全监管，依法查处违反网络安全监管的违法违规活动，打击网络借贷涉及的金融犯罪及相关犯罪。国家互联网信息办公室负责对金融信息服务、互联网信息内容等业务进行监管。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p
      align="center"
      style="text-align:center;">
      <b>第二章&emsp;备案管理</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第五条</b><span>&emsp;拟开展网络借贷信息中介服务的网络借贷信息中介机构及其分支机构，应当在领取营业执照后，于</span>10个工作日以内携带有关材料向工商登记注册地地方金融监管部门备案登记。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      地方金融监管部门负责为网络借贷信息中介机构办理备案登记。地方金融监管部门应当在网络借贷信息中介机构提交的备案登记材料齐备时予以受理，并在各省（区、市）规定的时限内完成备案登记手续。备案登记不构成对网络借贷信息中介机构经营能力、合规程度、资信状况的认可和评价。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      地方金融监管部门有权根据本办法和相关监管规则对备案登记后的网络借贷信息中介机构进行评估分类，并及时将备案登记信息及分类结果在官方网站上公示。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息中介机构完成地方金融监管部门备案登记后，应当按照通信主管部门的相关规定申请相应的电信业务经营许可；未按规定申请电信业务经营许可的，不得开展网络借贷信息中介业务。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息中介机构备案登记、评估分类等具体细则另行制定。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第六条</b>&emsp;开展网络借贷信息中介业务的机构，应当在经营范围中实质明确网络借贷信息中介，法律、行政法规另有规定的除外。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第七条</b><span>&emsp;网络借贷信息中介机构备案登记事项发生变更的，应当在</span>5个工作日以内向工商登记注册地地方金融监管部门报告并进行备案信息变更。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第八条</b><span>&emsp;经备案的网络借贷信息中介机构拟终止网络借贷信息中介服务的，应当在终止业务前提前至少</span>10个工作日，书面告知工商登记注册地地方金融监管部门，并办理备案注销。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      经备案登记的网络借贷信息中介机构依法解散或者依法宣告破产的，除依法进行清算外，由工商登记注册地地方金融监管部门注销其备案。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p
      align="center"
      style="text-align:center;">
      <b>第三章&emsp;业务规则与风险管理</b>
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第九条</b>&emsp;网络借贷信息中介机构应当履行下列义务：
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （一）依据法律法规及合同约定为出借人与借款人提供直接借贷信息的采集整理、甄别筛选、网上发布，以及资信评估、借贷撮合、融资咨询、在线争议解决等相关服务；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （二）对出借人与借款人的资格条件、信息的真实性、融资项目的真实性、合法性进行必要审核；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （三）采取措施防范欺诈行为，发现欺诈行为或其他损害出借人利益的情形，及时公告并终止相关网络借贷活动；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （四）持续开展网络借贷知识普及和风险教育活动，加强信息披露工作，引导出借人以小额分散的方式参与网络借贷，确保出借人充分知悉借贷风险；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （五）按照法律法规和网络借贷有关监管规定要求报送相关信息，其中网络借贷有关债权债务信息要及时向有关数据统计部门报送并登记；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （六）妥善保管出借人与借款人的资料和交易信息，不得删除、篡改，不得非法买卖、泄露出借人与借款人的基本信息和交易信息；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （七）依法履行客户身份识别、可疑交易报告、客户身份资料和交易记录保存等反洗钱和反恐怖融资义务；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （八）配合相关部门做好防范查处金融违法犯罪相关工作；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （九）按照相关要求做好互联网信息内容管理、网络与信息安全相关工作；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （十）国务院银行业监督管理机构、工商登记注册地省级人民政府规定的其他义务。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c ">
      <b>第十条</b>&emsp;网络借贷信息中介机构不得从事或者接受委托从事下列活动：
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c ">
      （一）为自身或变相为自身融资；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c ">
      （二）直接或间接接受、归集出借人的资金；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c ">
      （三）直接或变相向出借人提供担保或者承诺保本保息；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c ">
      （四）自行或委托、授权第三方在互联网、固定电话、移动电话等电子渠道以外的物理场所进行宣传或推介融资项目；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c ">
      （五）发放贷款，但法律法规另有规定的除外；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c ">
      （六）将融资项目的期限进行拆分；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c">
      （七）自行发售理财等金融产品募集资金，代销银行理财、券商资管、基金、保险或信托产品等金融产品；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c ">
      （八）开展类资产证券化业务或实现以打包资产、证券化资产、信托资产、基金份额等形式的债权转让行为；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c ">
      （九）除法律法规和网络借贷有关监管规定允许外，与其他机构投资、代理销售、经纪等业务进行任何形式的混合、捆绑、代理；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c">
      （十）虚构、夸大融资项目的真实性、收益前景，隐瞒融资项目的瑕疵及风险，以歧义性语言或其他欺骗性手段等进行虚假片面宣传或促销等，捏造、散布虚假信息或不完整信息损害他人商业信誉，误导出借人或借款人；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c">
      （十一）向借款用途为投资股票、场外配资、期货合约、结构化产品及其他衍生品等高风险的融资提供信息中介服务；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c ">
      （十二）从事股权众筹等业务；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c">
      （十三）法律法规、网络借贷有关监管规定禁止的其他活动。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第十一条</b>&emsp;参与网络借贷的出借人与借款人应当为网络借贷信息中介机构核实的实名注册用户。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第十二条</b>&emsp;借款人应当履行下列义务：
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （一）提供真实、准确、完整的用户信息及融资信息；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （二）提供在所有网络借贷信息中介机构未偿还借款信息；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （三）保证融资项目真实、合法，并按照约定用途使用借贷资金，不得用于出借等其他目的；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （四）按照约定向出借人如实报告影响或可能影响出借人权益的重大信息；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （五）确保自身具有与借款金额相匹配的还款能力并按照合同约定还款；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （六）借贷合同及有关协议约定的其他义务。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c">
      <b>第十三条</b>&emsp;借款人不得从事下列行为：
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c">
      （一）通过故意变换身份、虚构融资项目、夸大融资项目收益前景等形式的欺诈借款；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c">
      （二）同时通过多个网络借贷信息中介机构，或者通过变换项目名称、对项目内容进行非实质性变更等方式，就同一融资项目进行重复融资；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c">
      （三）在网络借贷信息中介机构以外的公开场所发布同一融资项目的信息；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c">
      （四）已发现网络借贷信息中介机构提供的服务中含有本办法第十条所列内容，仍进行交易；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;color:#ff711c">
      （五）法律法规和网络借贷有关监管规定禁止从事的其他活动。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第十四条</b>&emsp;参与网络借贷的出借人，应当具备投资风险意识、风险识别能力、拥有非保本类金融产品投资的经历并熟悉互联网。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第十五条</b>&emsp;参与网络借贷的出借人应当履行下列义务：
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （一）向网络借贷信息中介机构提供真实、准确、完整的身份等信息；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （二）出借资金为来源合法的自有资金；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （三）了解融资项目信贷风险，确认具有相应的风险认知和承受能力；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （四）自行承担借贷产生的本息损失；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （五）借贷合同及有关协议约定的其他义务。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第十六条</b>&emsp;网络借贷信息中介机构在互联网、固定电话、移动电话等电子渠道以外的物理场所只能进行信用信息采集、核实、贷后跟踪、抵质押管理等风险管理及网络借贷有关监管规定明确的部分必要经营环节。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第十七条</b>&emsp;网络借贷金额应当以小额为主。网络借贷信息中介机构应当根据本机构风险管理能力，控制同一借款人在同一网络借贷信息中介机构平台及不同网络借贷信息中介机构平台的借款余额上限，防范信贷集中风险。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>同一自然人在同一网络借贷信息中介机构平台的借款余额上限不超过人民币</span>20万元；同一法人或其他组织在同一网络借贷信息中介机构平台的借款余额上限不超过人民币100万元；同一自然人在不同网络借贷信息中介机构平台借款总余额不超过人民币100万元；同一法人或其他组织在不同网络借贷信息中介机构平台借款总余额不超过人民币500万元。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第十八条</b>&emsp;网络借贷信息中介机构应当按照国家网络安全相关规定和国家信息安全等级保护制度的要求，开展信息系统定级备案和等级测试，具有完善的防火墙、入侵检测、数据加密以及灾难恢复等网络安全设施和管理制度，建立信息科技管理、科技风险管理和科技审计有关制度，配置充足的资源，采取完善的管理控制措施和技术手段保障信息系统安全稳健运行，保护出借人与借款人的信息安全。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>网络借贷信息中介机构应当记录并留存借贷双方上网日志信息，信息交互内容等数据，留存期限为自借贷合同到期起</span>5年；每两年至少开展一次全面的安全评估，接受国家或行业主管部门的信息安全检查和审计。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息中介机构成立两年以内，应当建立或使用与其业务规模相匹配的应用级灾备系统设施。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第十九条</b><span>&emsp;网络借贷信息中介机构应当为单一融资项目设置募集期，最长不超过</span>20个工作日。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第二十条</b>&emsp;借款人支付的本金和利息应当归出借人所有。网络借贷信息中介机构应当与出借人、借款人另行约定费用标准和支付方式。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第二十一条</b>&emsp;网络借贷信息中介机构应当加强与金融信用信息基础数据库运行机构、征信机构等的业务合作，依法提供、查询和使用有关金融信用信息。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第二十二条</b>&emsp;各方参与网络借贷信息中介机构业务活动，需要对出借人与借款人的基本信息和交易信息等使用电子签名、电子认证时，应当遵守法律法规的规定，保障数据的真实性、完整性及电子签名、电子认证的法律效力。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息中介机构使用第三方数字认证系统，应当对第三方数字认证机构进行定期评估，保证有关认证安全可靠并具有独立性。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第二十三条</b>&emsp;网络借贷信息中介机构应当采取适当的方法和技术，记录并妥善保存网络借贷业务活动数据和资料，做好数据备份。保存期限应当符合法律法规及网络借贷有关监管规定的要求。借贷合同到期后应当至少保存５年。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第二十四条</b><span>&emsp;网络借贷信息中介机构暂停、终止业务时应当至少提前</span>10个工作日通过官方网站等有效渠道向出借人与借款人公告，并通过移动电话、固定电话等渠道通知出借人与借款人。网络借贷信息中介机构业务暂停或者终止，不影响已经签订的借贷合同当事人有关权利义务。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息中介机构因解散或宣告破产而终止的，应当在解散或破产前，妥善处理已撮合存续的借贷业务，清算事宜按照有关法律法规的规定办理。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息中介机构清算时，出借人与借款人的资金分别属于出借人与借款人，不属于网络借贷信息中介机构的财产，不列入清算财产。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p
      align="center"
      style="text-align:center;">
      <b>第四章&emsp;出借人与借款人保护</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第二十五条</b>&emsp;未经出借人授权，网络借贷信息中介机构不得以任何形式代出借人行使决策。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第二十六条</b>&emsp;网络借贷信息中介机构应当向出借人以醒目方式提示网络借贷风险和禁止性行为，并经出借人确认。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息中介机构应当对出借人的年龄、财务状况、投资经验、风险偏好、风险承受能力等进行尽职评估，不得向未进行风险评估的出借人提供交易服务。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息中介机构应当根据风险评估结果对出借人实行分级管理，设置可动态调整的出借限额和出借标的限制。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第二十七条</b>&emsp;网络借贷信息中介机构应当加强出借人与借款人信息管理，确保出借人与借款人信息采集、处理及使用的合法性和安全性。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息中介机构及其资金存管机构、其他各类外包服务机构等应当为业务开展过程中收集的出借人与借款人信息保密，未经出借人与借款人同意，不得将出借人与借款人提供的信息用于所提供服务之外的目的。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      在中国境内收集的出借人与借款人信息的储存、处理和分析应当在中国境内进行。除法律法规另有规定外，网络借贷信息中介机构不得向境外提供境内出借人和借款人信息。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第二十八条</b>&emsp;网络借贷信息中介机构应当实行自身资金与出借人和借款人资金的隔离管理，并选择符合条件的银行业金融机构作为出借人与借款人的资金存管机构。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第二十九条</b>&emsp;出借人与网络借贷信息中介机构之间、出借人与借款人之间、借款人与网络借贷信息中介机构之间等纠纷，可以通过以下途径解决：
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （一）自行和解；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （二）请求行业自律组织调解；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （三）向仲裁部门申请仲裁；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （四）向人民法院提起诉讼。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p
      align="center"
      style="text-align:center;">
      <b>第五章&emsp;信息披露</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第三十条</b>&emsp;网络借贷信息中介机构应当在其官方网站上向出借人充分披露借款人基本信息、融资项目基本信息、风险评估及可能产生的风险结果、已撮合未到期融资项目资金运用情况等有关信息。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      披露内容应符合法律法规关于国家秘密、商业秘密、个人隐私的有关规定。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第三十一条</b>&emsp;网络借贷信息中介机构应当及时在其官方网站显著位置披露本机构所撮合借贷项目等经营管理信息。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息中介机构应当在其官方网站上建立业务活动经营管理信息披露专栏，定期以公告形式向公众披露年度报告、法律法规、网络借贷有关监管规定。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息中介机构应当聘请会计师事务所定期对本机构出借人与借款人资金存管、信息披露情况、信息科技基础设施安全、经营合规性等重点环节实施审计，并且应当聘请有资质的信息安全测评认证机构定期对信息安全实施测评认证，向出借人与借款人等披露审计和测评认证结果。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息中介机构应当引入律师事务所、信息系统安全评价等第三方机构，对网络信息中介机构合规和信息系统稳健情况进行评估。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息中介机构应当将定期信息披露公告文稿和相关备查文件报送工商登记注册地地方金融监管部门，并置备于机构住所供社会公众查阅。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第三十二条</b>&emsp;网络借贷信息中介机构的董事、监事、高级管理人员应当忠实、勤勉地履行职责，保证披露的信息真实、准确、完整、及时、公平，不得有虚假记载、误导性陈述或者重大遗漏。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      借款人应当配合网络借贷信息中介机构及出借人对融资项目有关信息的调查核实，保证提供的信息真实、准确、完整。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息披露具体细则另行制定。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p
      align="center"
      style="text-align:center;">
      <b>第六章&emsp;监督管理</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第三十三条</b>&emsp;国务院银行业监督管理机构及其派出机构负责制定统一的规范发展政策措施和监督管理制度，负责网络借贷信息中介机构的日常行为监管，指导和配合地方人民政府做好网络借贷信息中介机构的机构监管和风险处置工作，建立跨部门跨地区监管协调机制。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      各地方金融监管部门具体负责本辖区网络借贷信息中介机构的机构监管，包括对本辖区网络借贷信息中介机构的规范引导、备案管理和风险防范、处置工作。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第三十四条</b>&emsp;中国互联网金融协会从事网络借贷行业自律管理，并履行下列职责：
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （一）制定自律规则、经营细则和行业标准并组织实施，教育会员遵守法律法规和网络借贷有关监管规定；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （二）依法维护会员的合法权益，协调会员关系，组织相关培训，向会员提供行业信息、法律咨询等服务，调解纠纷；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （三）受理有关投诉和举报，开展自律检查；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （四）成立网络借贷专业委员会；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （五）法律法规和网络借贷有关监管规定赋予的其他职责。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第三十五条</b>&emsp;借款人、出借人、网络借贷信息中介机构、资金存管机构、担保人等应当签订资金存管协议，明确各自权利义务和违约责任。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      资金存管机构对出借人与借款人开立和使用资金账户进行管理和监督，并根据合同约定，对出借人与借款人的资金进行存管、划付、核算和监督。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      资金存管机构承担实名开户和履行合同约定及借贷交易指令表面一致性的形式审核责任，但不承担融资项目及借贷交易信息真实性的实质审核责任。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      资金存管机构应当按照网络借贷有关监管规定报送数据信息并依法接受相关监督管理。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第三十六条</b>&emsp;网络借贷信息中介机构应当在下列重大事件发生后，立即采取应急措施并向工商登记注册地地方金融监管部门报告：
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （一）因经营不善等原因出现重大经营风险；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （二）网络借贷信息中介机构或其董事、监事、高级管理人员发生重大违法违规行为；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （三）因商业欺诈行为被起诉，包括违规担保、夸大宣传、虚构隐瞒事实、发布虚假信息、签订虚假合同、错误处置资金等行为。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      地方金融监管部门应当建立网络借贷行业重大事件的发现、报告和处置制度，制定处置预案，及时、有效地协调处置有关重大事件。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      地方金融监管部门应当及时将本辖区网络借贷信息中介机构重大风险及处置情况信息报送省级人民政府、国务院银行业监督管理机构和中国人民银行。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第三十七条</b><span>&emsp;除本办法第七条规定的事项外，网络借贷信息中介机构发生下列情形的，应当在</span>5个工作日以内向工商登记注册地地方金融监管部门报告：
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （一）因违规经营行为被查处或被起诉；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （二）董事、监事、高级管理人员违反境内外相关法律法规行为；
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      （三）国务院银行业监督管理机构、地方金融监管部门等要求的其他情形。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第三十八条</b><span>&emsp;网络借贷信息中介机构应当聘请会计师事务所进行年度审计，并在上一会计年度结束之日起</span>4个月内向工商登记注册地地方金融监管部门报送年度审计报告。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p
      align="center"
      style="text-align:center;">
      <b>第七章&emsp;法律责任</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第三十九条</b>&emsp;地方金融监管部门存在未依照本办法规定报告重大风险和处置情况、未依照本办法规定向国务院银行业监督管理机构提供行业统计或行业报告等违反法律法规及本办法规定情形的，应当对有关责任人依法给予行政处分；构成犯罪的，依法追究刑事责任。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第四十条</b>&emsp;网络借贷信息中介机构违反法律法规和网络借贷有关监管规定，有关法律法规有处罚规定的，依照其规定给予处罚；有关法律法规未作处罚规定的，工商登记注册地地方金融监管部门可以采取监管谈话、出具警示函、责令改正、通报批评、将其违法违规和不履行公开承诺等情况记入诚信档案并公布等监管措施，以及给予警告、人民币３万元以下罚款和依法可以采取的其他处罚措施；构成犯罪的，依法追究刑事责任。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      网络借贷信息中介机构违反法律规定从事非法集资活动或欺诈的，按照相关法律法规和工作机制处理；构成犯罪的，依法追究刑事责任。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第四十一条</b>&emsp;网络借贷信息中介机构的出借人及借款人违反法律法规和网络借贷有关监管规定，依照有关规定给予处罚；构成犯罪的，依法追究刑事责任。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p
      align="center"
      style="text-align:center;">
      <b>第八章&emsp;附&emsp;则</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第四十二条</b>&emsp;银行业金融机构及国务院银行业监督管理机构批准设立的其他金融机构和省级人民政府批准设立的融资担保公司、小额贷款公司等投资设立具有独立法人资格的网络借贷信息中介机构，设立办法另行制定。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第四十三条</b>&emsp;中国互联网金融协会网络借贷专业委员会按照《关于促进互联网金融健康发展的指导意见》和协会章程开展自律并接受相关监管部门指导。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第四十四条</b><span>&emsp;本办法实施前设立的网络借贷信息中介机构不符合本办法规定的，除违法犯罪行为按照本办法第四十条处理外，由地方金融监管部门要求其整改，整改期不超过</span>12个月。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第四十五条</b>&emsp;省级人民政府可以根据本办法制定实施细则，并报国务院银行业监督管理机构备案。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第四十六条</b>&emsp;本办法解释权归国务院银行业监督管理机构、工业和信息化部、公安部、国家互联网信息办公室。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>第四十七条</b>&emsp;本办法所称不超过、以下、以内，包括本数。
    </p>
    <p>
      <br>
      <b>附件：</b><b />
    </p>
    <p
      align="center"
      style="text-align:center;">
      <b>《网络借贷信息中介机构业务活动管理暂行办法》答记者问</b><b />
    </p>
    <p>
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      按照党中央、国务院工作部署和人民银行等十部委《关于促进互联网金融健康发展的指导意见》（以下简称《指导意见》）有关职责分工，银监会会同工业和信息化部、公安部、国家互联网信息办公室等部门研究起草了《网络借贷信息中介机构业务活动管理暂行办法》（以下简称《办法》），现就有关问题解答如下：
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>一、《办法》中网络借贷、网络借贷业务、网络借贷信息中介机构分别指什么？</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>答：《办法》落实了《指导意见》的有关要求，规定网络借贷（以下简称</span>“网贷”）是指个体和个体之间通过互联网平台实现的直接借贷，即大众所熟知的P2P个体网贷，属于民间借贷范畴，受合同法、民法通则等法律法规以及最高人民法院有关司法解释规范。网贷业务是以互联网为主要渠道，为借款人和出借人实现直接借贷提供信息搜集、信息公布、资信评估、信息交互、借贷撮合等服务。网贷信息中介机构（以下简称“网贷机构”）是指依法设立，专门经营网贷业务的金融信息服务中介机构，其本质是信息中介而非信用中介，因此不得吸收公众存款、归集资金设立资金池、不得自身为出借人提供任何形式的担保等。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      目前，许多网贷机构背离了信息中介的定性，承诺担保增信、错配资金池等，已由信息中介异化为信用中介，为此，《办法》将重点对此类行为进行规范，以净化市场环境，保护金融消费者权益，使网贷机构回归到信息中介的本质。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>二、网贷的特点及发展网贷的意义有哪些？</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>答：网贷利用互联网信息技术，不受时空限制，使资金提供方与资金需求方在平台上直接对接，进行投融资活动，拓宽了金融服务的目标群体和范围，有助于为社会大多数阶层和群体提供可得、便利的普惠金融服务，进一步实现了小额投融资活动低成本、高效率、大众化，对于</span>“稳增长、调结构、促发展、惠民生”具有重要意义。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      此外网贷机构与传统金融机构相互补充、相互促进，在完善金融体系，提高金融效率，弥补小微企业融资缺口，缓解小微企业融资难以及满足民间投资需求等方面发挥了积极作用。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>三、当前我国网贷行业基本情况及存在的主要问题？</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>答：网贷作为互联网金融业态的重要组成部分，近几年的发展呈现出</span>“快、偏、乱”的现象，即行业规模增长势头过快，业务创新偏离轨道、风险乱象时有发生：一是规模增长势头过快。近两年网贷行业无论在机构数量还是业务规模均呈现出迅猛增长的势头，据不完全统计，截至2016年6月底全国正常运营的网贷机构共2349家，借贷余额6212.61亿元，两项数据比2014年末分别增长了49.1%、499.7%。二是业务创新偏离轨道。目前大部分网贷机构偏离信息中介定位以及服务小微和依托互联网经营的本质，异化为信用中介，存在自融、违规放贷、设立资金池、期限拆分、大量线下营销等行为。三是风险乱象时有发生。网贷行业中问题机构不断累积，风险事件时有发生，据不完全统计，截至2016年6月底全国累计问题平台1778家，约占全国机构总数的43.1%，这些问题机构部分受资本实力及自身经营管理能力限制，当借贷大量违约、经营难以为继时，出现“卷款”、“跑路”等情况，部分机构销售不同形式的投资产品，规避相关金融产品的认购门槛及投资者适当性要求，在逃避监管的同时，加剧风险传播，部分机构甚至通过假标、资金池和高收益等手段，进行自融、庞氏骗局，碰触非法集资底线。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>四、《办法》确定的网贷行业监管的总体原则有哪些？</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>答：按照《指导意见》明确的</span>“鼓励创新、防范风险、趋利避害、健康发展”的总体要求和“依法、适度、分类、协同、创新”的监管原则，《办法》确定了网贷行业监管总体原则：一是强调机构本质属性，加强事中事后行为监管。网贷机构本质上是信息中介机构，不是信用中介机构，但其开展的网贷业务是金融信息中介业务，涉及资金融通及相关风险管理。对网贷业务的监管，重点在于业务基本规则的制定完善，而非机构和业务的准入审批，应着力加强事中事后行为监管，以保护相关当事人合法权益。二是坚持底线监管思维，实行负面清单管理。通过负面清单界定网贷业务的边界，明确网贷机构不能从事的十三项禁止性行为，对符合法律法规的网贷业务和创新活动，给予支持和保护；对以网贷名义进行非法集资等非法金融活动，坚决予以打击和取缔；加强信息披露，完善风险监测，守住不发生区域性系统性风险的底线。三是创新行业监管方式，实行分工协同监管。网贷作为新兴的互联网金融业态，具有跨区域、跨领域的特征，传统的监管模式无法适应网贷行业的监管需求，因此，要充分发挥网贷业务国家相关管理部门、地方人民政府的作用，发挥各方优势，在明确分工的前提下，加强沟通、协作，形成有效的监管合力。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>五、《办法》确立的网贷行业的基本管理体制及各方职责具体是什么？</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <span>答：《指导意见》将网贷机构定性为信息中介，且将网贷归属于民间借贷范畴。根据关于界定中央和地方金融监管职责分工的有关规定，明确对于非存款类金融活动的监管，由中央金融监管部门制定统一的业务规则和监管规则，督促和指导地方人民政府金融监管工作，由省级人民政府对机构实施监管，承担相应的风险处置责任，并加强对民间借贷的引导和规范，防范和化解地方金融风险。鉴于网贷行业跨地区经营且风险外溢性较大，按照行为监管与机构监管并行的监管思路，《办法》本着</span>“双负责”的原则，明确银监会及其派出机构作为中央金融监管部门负责对网贷机构实施行为监管，具体包括制定统一的规范发展政策措施和监督管理制度，并负责网贷机构日常经营行为的监管；明确地方金融监管部门负责对本辖区网贷机构实施机构监管，具体包括对本辖区网贷机构进行规范引导、备案管理和风险防范及处置工作。另外，网贷行业作为新兴业态，其业务管理涉及多个部门职责，应坚持协同监管，《办法》明确工业和信息化部主要职责是对网贷机构具体业务中涉及的电信业务进行监管；公安部主要职责是牵头对网贷机构业务活动进行互联网安全监管，打击网络借贷涉及的金融犯罪；国家互联网信息办公室主要职责是负责对金融信息服务、互联网信息内容等业务进行监管。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>六、《办法》对于网贷业务的主要管理措施有哪些？</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      答：一是对业务经营活动实行负面清单管理。考虑到网贷机构处于探索创新阶段，业务模式尚待观察，因此，《办法》对其业务经营范围采用以负面清单为主的管理模式，明确了包括不得吸收公众存款、不得设立资金池、不得提供担保或承诺保本保息、不得发售金融理财产品、不得开展类资产证券化等形式的债权转让等十三项禁止性行为。在政策安排上，允许网贷机构引入第三方机构进行担保或者与保险公司开展相关业务合作。二是对客户资金实行第三方存管。为防范网贷机构设立资金池和欺诈、侵占、挪用客户资金，增强市场信心，《办法》规定对客户资金和网贷机构自身资金实行分账管理，由银行业金融机构对客户资金实行第三方存管，对客户资金进行管理和监督，资金存管机构与网贷机构应明确约定各方责任边界，便于做好风险识别和风险控制，实现尽职免责。三是限制借款集中度风险。为更好地保护出借人权益和降低网贷机构道德风险，并与非法吸收公众存款有关司法解释及立案标准相衔接，《办法》规定网贷具体金额应当以小额为主。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>七、《办法》对于出借人和借款人的具体行为有哪些规定？</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      答：《办法》对消费者权益保护进行了重点考量，注重对出借人和借款人，尤其是对出借人的保护，在第四章以专章形式对借贷决策、风险揭示及评估、出借人和借款人信息、资金保护以及纠纷解决等问题进行了详细规定，确保出借人和借款人的合法权益不受损害。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      《办法》也对出借人和借款人的行为进行了规范，明确规定参与网贷的出借人与借款人应当实名注册；借款人应当提供准确信息，确保融资项目真实、合法，按照约定使用资金，严格禁止借款人欺诈、重复融资等。《办法》还要求出借人应当具备非保本类金融产品投资的经历并熟悉互联网，应当提供真实、准确、完整的身份信息，出借资金来源合法，拥有风险认知和承受能力以及自行承担借贷产生的本息损失。这些规定，本质上属于合格投资者条款，其目的是为了在行业发展初期，更好地防范非理性投资，引导投资者风险自担，进一步保护出借人合法权益。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>八、客户资金实行银行业金融机构第三方存管制度对行业规范发展的作用有哪些？</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      答：按照《指导意见》有关规定，网贷机构应当选择符合条件的银行业金融机构作为第三方资金存管机构，对客户资金进行管理和监督，实现客户资金和网贷机构自身资金分账管理。实行客户资金第三方存管制度将有效防范网贷机构设立资金池和欺诈、侵占、挪用客户资金风险，有利于资金的安全与隔离，对于规范行业健康发展具有重要意义。银行业金融机构应当按照合同约定，履行交易资金划付、资金核算和监督等职责，将网贷机构的资金与客户的资金分账管理、分开存放，确保资金流向符合出借人的真实意愿，有效防范风险。下一步，银监会将制定网贷客户资金第三方存管具体办法，明确银行业金融机构对网络借贷资金监督管理职责以及存管银行的条件等，更好地满足当前网贷行业资金存管的市场需求。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>九、信息披露制度对整个行业的意义是什么？</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      答：加强对网贷机构的信息披露要求、完善相关信息披露制度，对于改进行业形象、提升网贷机构公信力、完善行业事中事后监管、防范行业风险、保护出借人与借款人利益具有十分重要的意义。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      根据行业及部分监管部门反映，在《办法》中对信息披露进行较为详细的规定缺乏可操作性，且部分指标的设置还有待于行业实践，因此目前《办法》只对信息披露进行原则性规定，银监会拟在后续有关细则中，结合行业的一般做法和监管需要，对行业的相应指标，包括坏账率、逾期率和代偿金额等进行明确定义。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      &nbsp;
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      <b>十、《办法》出台后，对网贷行业会产生什么影响？银监会下一步的工作主要有哪些？</b><b />
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      答：《办法》通过社会公开征求意见和相关部门定向征求意见，并经相关部门进行合法性评估和第三方评估等形式，充分征求了社会各界的意见，各方反馈总体符合预期，我们也根据相关意见对《办法》进行了多轮修改完善，既充分考虑当前行业风险突出，亟待规范整顿的现状，又尊重行业现实，注重把握好行业风险底线与可持续发展的平衡，保护和支持依法合规的网贷业务和创新活动，避免《办法》出台造成对行业的冲击。
    </p>
    <p style="margin-left:0pt;text-indent:24pt;">
      《办法》作为行业经营和监管的基本制度安排，明确了网贷监管体制机制及各相关主体责任、网贷业务规则和风险管理要求、借款人和出借人的义务、信息披露及资金第三方存管等内容，全面系统的规范了网贷机构及其业务行为，为行业的发展明确了方向，进一步引导网贷机构回归信息中介、小额分散的普惠金融本质，促使网贷行业正本清源，同时，网贷机构线下经营现象将得到遏制，网贷机构将逐渐回归互联网金融本质，利用大数据、云计算等全新技术手段，依托互联网平台来开展相关业务，整顿网贷行业违规行为，防范和化解网贷风险，提升公众法律和风险意识，引导和促进网贷行业早日走上正轨，形成可持续的发展模式。
    </p>
    <p>
      《办法》正式发布后，银监会将密切关注各方反应和行业动向，尽快发布网贷客户资金第三方存管、网贷机构备案以及网贷机构信息披露等配套制度，完善网贷行业监管制度体系。
    </p>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '法律文件'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .law_jd
    font-size: $fontsize-small-ss
    padding: 1.02rem 5% 0.2rem
    background-color: #fff
    p
      line-height: 0.36rem
      b
        font-weight: bold
        span
          font-weight: bold
</style>
