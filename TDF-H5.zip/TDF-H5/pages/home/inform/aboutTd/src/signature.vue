<template>
  <cube-scroll>
    <div class="signature">
      <div class="signature_bg"/>
    </div>
  </cube-scroll>
</template>
<style lang="stylus" scoped>
  .signature
    border-top: 0.2rem solid $color-background
    background-color: $color-white
    .signature_bg
      width: 6.92rem
      height: 6.31rem
      margin: 0 auto
      background: url(../../../../../assets/images/inform/signature.png) no-repeat
      background-size: 100% 100%
</style>
