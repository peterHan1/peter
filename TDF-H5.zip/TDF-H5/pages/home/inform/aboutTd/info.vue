<template>
  <div class="info">
    <td-header title="关于拓道"/>
    <h3>从业机构平台信息</h3>
    <table>
      <tr>
        <th>网站或平台地址</th>
        <td>https://www.51tuodao.com/</td>
      </tr>
      <tr>
        <th>IP地址</th>
        <td>115.239.210.27</td>
      </tr>
      <tr>
        <th>平台上线运营时间</th>
        <td>2013-12-09</td>
      </tr>
      <tr>
        <th>注册协议模板</th>
        <td><a href="">注册协议</a></td>
      </tr>
      <tr>
        <th>企业全称及简称 </th>
        <td>全称：杭州拓道互联网金融服务有限公司<br>简称：拓道金服</td>
      </tr>
      <tr>
        <th>分支机构</th>
        <td>无</td>
      </tr>
      <tr>
        <th>统一社会信用代码</th>
        <td>91330106082106019P</td>
      </tr>
      <tr>
        <th>注册/实缴资本</th>
        <td>5000万/5000万</td>
      </tr>
      <tr>
        <th>注册地址</th>
        <td>杭州市西湖区中节能西溪首座B2裙楼</td>
      </tr>
      <tr>
        <th>实际办公地址</th>
        <td>杭州市西湖区中节能西溪首座B2裙楼</td>
      </tr>
      <tr>
        <th>成立时间</th>
        <td>2013-11-05</td>
      </tr>
      <tr>
        <th>营业期限</th>
        <td>2013年11月05日至2023年11月04日</td>
      </tr>
      <tr>
        <th>法定代表人</th>
        <td>张罗军</td>
      </tr>
      <tr>
        <th>经营状态</th>
        <td>开业</td>
      </tr>
      <tr>
        <th>经营范围</th>
        <td class="tdStyle">服务：互联网金融服务（由国家金融监管部门核准的金融业务除外），接受金融机构委托从事金融信息技术外包， 接受金融机构委托从事金融业务流程外包，接受金融机构委托从事金融知识流程外包，投资咨询、投资管理（以上项目除证券、期货，未经金融等监管部门批准， 不得从事向公众融资存款，融资担保、代客户理财等金融服务），企业管理咨询，经济信息咨询、商务信息咨询（除中介），企业营销策划，市场信息咨询与调查， 会展服务咨询，计算机软硬件、通讯设备的技术开发、技术服务、成果转让；批发、零售：计算机软硬件，通讯设备(除专控)。(依法须经批准的项目，经相关部门批准后方可开展经营活动)</td>
      </tr>
      <tr>
        <th>客服电话</th>
        <td>400-85-666-85</td>
      </tr>
      <tr>
        <th>投诉电话</th>
        <td>0571-87208395</td>
      </tr>
      <tr>
        <th>邮编</th>
        <td>310012</td>
      </tr>
      <tr>
        <th>ICP备案证号 </th>
        <td>浙ICP备13034095号</td>
      </tr>
      <tr>
        <th>增值电信业务经营许可证编号 </th>
        <td>浙B2-20160394</td>
      </tr>
      <tr>
        <th>信息安全测评认证</th>
        <td>信息系统安全等级保护3级</td>
      </tr>
      <tr>
        <th>信息系统安全等级保护证书编号</th>
        <td>330117-13024-00001</td>
      </tr>
      <tr>
        <th>微信订阅号</th>
        <td>tuodao666</td>
      </tr>
      <tr>
        <th>微博地址</th>
        <td>http://weibo.com/51tuodao</td>
      </tr>
      <tr>
        <th>平台APP名称</th>
        <td>拓道金服</td>
      </tr>
      <tr>
        <th>平台APP上线时间</th>
        <td>2015-8-13</td>
      </tr>
    </table>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '关于拓道'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .info
    background-color: white
    padding: 1.08rem 0.3rem 0.2rem
    h3
      font-size: $fontsize-medium
      color:$color-gray1
      height:0.8rem
      line-height:0.8rem
      font-weight: normal
      border-bottom: 1px solid $color-gray5
  table
    width:100%
    font-size: $fontsize-small-sss
    color:$color-gray8
    border-collapse: collapse
    tr
      th
        border: 1px solid $color-gray5
        width:30%
        padding:0.28rem 0.1rem
        text-align:left
        font-weight: normal
      td
        border: 1px solid $color-gray5
        width:70%
        padding:0.28rem 0.1rem
        text-align:right
        a
          color:$color-gray8
      .tdStyle
        text-align: left
        padding:0.2rem 0.1rem
</style>
