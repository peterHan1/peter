<template>
  <div class="audit">
    <td-header title="审计报告"/>
  </div>
</template>
<script>
import img from '../../../../assets/images/inform/signature-2.png'
export default {
  metaInfo: {
    title: '审计报告'
  },
  data() {
    return {
      items: `img`
    }
  }
}
</script>
<style lang="stylus" scoped>
</style>
