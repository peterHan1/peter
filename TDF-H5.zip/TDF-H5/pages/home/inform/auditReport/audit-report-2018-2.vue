<template>
  <div class="audit">
    <td-header title="审计报告"/>
  </div>
</template>
<script>
import img1 from '../../../../assets/images/inform/audit/2018-2/audit-2018-01.png'
import img2 from '../../../../assets/images/inform/audit/2018-2/audit-2018-02.png'
import img3 from '../../../../assets/images/inform/audit/2018-2/audit-2018-03.png'
import img4 from '../../../../assets/images/inform/audit/2018-2/audit-2018-04.png'
import img5 from '../../../../assets/images/inform/audit/2018-2/audit-2018-05.png'
import img6 from '../../../../assets/images/inform/audit/2018-2/audit-2018-06.png'
import img7 from '../../../../assets/images/inform/audit/2018-2/audit-2018-07.png'
import img8 from '../../../../assets/images/inform/audit/2018-2/audit-2018-08.png'
import img9 from '../../../../assets/images/inform/audit/2018-2/audit-2018-09.png'
import img10 from '../../../../assets/images/inform/audit/2018-2/audit-2018-10.png'
import img11 from '../../../../assets/images/inform/audit/2018-2/audit-2018-11.png'
import img12 from '../../../../assets/images/inform/audit/2018-2/audit-2018-12.png'
import img13 from '../../../../assets/images/inform/audit/2018-2/audit-2018-13.png'
import img14 from '../../../../assets/images/inform/audit/2018-2/audit-2018-14.png'
import img15 from '../../../../assets/images/inform/audit/2018-2/audit-2018-15.png'
import img16 from '../../../../assets/images/inform/audit/2018-2/audit-2018-16.png'
import img17 from '../../../../assets/images/inform/audit/2018-2/audit-2018-17.png'
import img18 from '../../../../assets/images/inform/audit/2018-2/audit-2018-18.png'
import img19 from '../../../../assets/images/inform/audit/2018-2/audit-2018-19.png'
import img20 from '../../../../assets/images/inform/audit/2018-2/audit-2018-20.png'
import img21 from '../../../../assets/images/inform/audit/2018-2/audit-2018-21.png'
import img22 from '../../../../assets/images/inform/audit/2018-2/audit-2018-22.png'
import img23 from '../../../../assets/images/inform/audit/2018-2/audit-2018-23.png'
import img24 from '../../../../assets/images/inform/audit/2018-2/audit-2018-24.png'
import img25 from '../../../../assets/images/inform/audit/2018-2/audit-2018-25.png'
import img26 from '../../../../assets/images/inform/audit/2018-2/audit-2018-26.png'
import img27 from '../../../../assets/images/inform/audit/2018-2/audit-2018-27.png'
import img28 from '../../../../assets/images/inform/audit/2018-2/audit-2018-28.png'
export default {
  metaInfo: {
    title: '审计报告'
  },
  data() {
    return {
      items: `img1, img2, img3, img4, img5, img6, img7, img8, img9, img10, img11, img12, img13, img14, img15, img16, img17, img18, img19, img20, img21, img22, img23, img24, img25, img26, img27, img28`
    }
  }
}
</script>
<style lang="stylus" scoped>
</style>
