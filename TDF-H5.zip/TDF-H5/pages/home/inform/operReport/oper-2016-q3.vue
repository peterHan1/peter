<template>
  <div class="year_2016">
    <td-header title="拓道金服2016年第三季度运营报告"/>
    <div>
      <span class="year_2016_bg1"/>
    </div>
    <div>
      <span class="year_2016_bg2"/>
    </div>
    <div >
      <span class="year_2016_bg3"/>
    </div>
    <div>
      <span class="year_2016_bg4"/>
    </div>
    <div>
      <span class="year_2016_bg5"/>
    </div>
    <div>
      <span class="year_2016_bg6"/>
    </div>
    <div>
      <span class="year_2016_bg7"/>
    </div>
    <div>
      <span class="year_2016_bg8"/>
    </div>
    <div>
      <span class="year_2016_bg9"/>
    </div>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2016第三季度运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
</style>
