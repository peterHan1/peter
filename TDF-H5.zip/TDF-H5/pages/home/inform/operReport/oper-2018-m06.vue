<template>
  <div class="month-6">
    <td-header title="拓道金服2018年度6月份运营报告"/>
    <div class="abos-bg"/>
    <div class="trends-bg"/>
    <div class="stands-out"/>
    <div class="datass-bg"/>
    <div class="invests-bg"/>
    <div class="deadlines-bg"/>
    <div class="constellation-bg"/>
    <div class="incidents-bg"/>
    <div class="inform-charge"/>
    <div class="footer-bg"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2018年度6月份运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .month-6
    overflow:hidden
    padding-top: 0.88rem
    background-color: $color-white
    span
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      overflow: hidden
    .abos-bg
      height:2.8rem
      background:url(../../../../assets/images/oper/oper-2018-m6/img1.png) no-repeat
      background-size:100% 100%
    .trends-bg
      height:5rem
      background:url(../../../../assets/images/oper/oper-2018-m6/img2.jpg) no-repeat
      background-size:100% 100%
    .stands-out
      height:8.88rem
      background:url(../../../../assets/images/oper/oper-2018-m6/img3.jpg) no-repeat
      background-size:100% 100%
    .datass-bg
      height:7.92rem
      background:url(../../../../assets/images/oper/oper-2018-m6/img4.jpg) no-repeat
      background-size:100% 100%
    .invests-bg
      height:8.01rem
      background:url(../../../../assets/images/oper/oper-2018-m6/img5.jpg) no-repeat
      background-size:100% 100%
    .deadlines-bg
      height:13.09rem
      background:url(../../../../assets/images/oper/oper-2018-m6/img6.jpg) no-repeat
      background-size:100% 100%
    .constellation-bg
      height:2.79rem
      background:url(../../../../assets/images/oper/oper-2018-m6/img7.jpg) no-repeat
      background-size:100% 100%
    .incidents-bg
      height:8.56rem
      background:url(../../../../assets/images/oper/oper-2018-m6/img8.jpg) no-repeat
      background-size:100% 100%
    .footer-bg
      height:3.71rem
      background:url(../../../../assets/images/oper/oper-2018-m6/img9.png) no-repeat
      background-size:100% 100%
    .inform-charge
      height: 12.58rem
      background: url(../../../../assets/images/inform/inform-charge.jpg) no-repeat
      background-size: 100% 100%
</style>
