<template>
  <div class="month-1">
    <td-header title="拓道金服2018年度1月份运营报告"/>
    <div class="oper-title"/>
    <div class="abos-bg"/>
    <div class="trends-bg"/>
    <div class="stands-out"/>
    <div class="datass-bg"/>
    <div class="invests-bg"/>
    <div class="deadlines-bg"/>
    <div class="statisticss-bg"/>
    <div class="rankings-city"/>
    <div class="ratios-bg"/>
    <div class="conss-bg"/>
    <div class="footer"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2018年1月份运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .month-1
    overflow:hidden
    padding-top: 0.88rem
    background-color: $color-white
    span
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      overflow: hidden
    .oper-title
      width:100%
      margin:0
      height:3.29rem
      background:url(../../../../assets/images/oper/oper-2018-m1/img1.png) no-repeat
      background-size:100% 100%
    .abos
      margin:-0.85rem 0 0 0
    .abos-bg
      height:4.53rem
      background:url(../../../../assets/images/oper/oper-2018-m1/img2.png) no-repeat
      background-size:100% 100%
    .trends-bg
      width:6.38rem
      height:1.97rem
      background:url(../../../../assets/images/oper/oper-2018-m1/img3.png) no-repeat
      background-size:100% 100%
    .stands-out
      width:7.05rem
      height:6.03rem
      margin-top:0.5rem
      background:url(../../../../assets/images/oper/oper-2018-m1/img4.png) no-repeat
      background-size:100% 100%
    .datass-bg
      width:7.01rem
      height:6.94rem
      margin-top:0.46rem
      background:url(../../../../assets/images/oper/oper-2018-m1/img5.png) no-repeat
      background-size:100% 100%
    .invests-bg
      height:4.26rem
      margin-top:0.43rem
      background:url(../../../../assets/images/oper/oper-2018-m1/img6.png) no-repeat
      background-size:100% 100%
    .deadlines-bg
      height:3.13rem
      margin-top:0.4rem
      background:url(../../../../assets/images/oper/oper-2018-m1/img7.png) no-repeat
      background-size:100% 100%
    .statisticss-bg
      height: 7.61rem
      margin-top:0.97rem
      background: url(../../../../assets/images/oper/oper-2018-m1/img8.png) no-repeat
      background-size: 100% 100%
    .rankings-city
      height:4.26rem
      margin-top:0.5rem
      background:url(../../../../assets/images/oper/oper-2018-m1/img9.png) no-repeat
      background-size: 100% 100%
    .ratios-bg
      height: 2.42rem
      margin-top:0.5rem
      background: url(../../../../assets/images/oper/oper-2018-m1/img10.png) no-repeat
      background-size: 100% 100%
    .conss-bg
      height: 2.06rem
      margin-top:0.45rem
      background: url(../../../../assets/images/oper/oper-2018-m1/img11.png) no-repeat
      background-size: 100% 100%
    .footer
      height:2.5rem
      margin-top:0.57rem
      background: url(../../../../assets/images/oper/oper-2018-m1/img12.png) no-repeat
      background-size: 100% 100%
</style>
