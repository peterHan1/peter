<template>
  <div class="jd-1-16">
    <td-header title="拓道金服2016年第一季度运营报告"/>
    <div class="jd-1-bg1"/>
    <div class="jd-1-bg2"/>
    <div class="jd-1-bg3"/>
    <div class="jd-1-bg4"/>
    <div class="jd-1-bg5"/>
    <div class="jd-1-bg6"/>
    <div class="jd-1-bg7"/>
    <div class="jd-1-bg8"/>
    <div class="jd-1-bg9"/>
    <div class="jd-1-bg10"/>
    <div class="jd-1-bg11"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2016第一季度运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .jd-1-16
    overflow:hidden
    padding-top: 0.88rem
    background-color:$color-white
    i
      color: $color-gray1
      font-weight: bold
    div
      width:100%
    .jd-1-bg1
      height:5.23rem
      background:url(../../../../assets/images/oper/oper-2016/2016-1-1.jpg) no-repeat
      background-position: center
      background-size: 100% 100%
    .jd-1-bg2
      height:6.74rem
      background:url(../../../../assets/images/oper/oper-2016/2016-1-2.jpg) no-repeat
      background-position: center
      background-size: 100% 100%
    .jd-1-bg3
      height:7.33rem
      background:url(../../../../assets/images/oper/oper-2016/2016-1-3.jpg) no-repeat
      background-position: center
      background-size: 100% 100%
    .jd-1-bg4
      height:7.66rem
      background:url(../../../../assets/images/oper/oper-2016/2016-1-4.jpg) no-repeat
      background-position: center
      background-size: 100% 100%
    .jd-1-bg5
      height:7.41rem
      background:url(../../../../assets/images/oper/oper-2016/2016-1-5.jpg) no-repeat
      background-position: center
      background-size: 100% 100%
    .jd-1-bg6
      height:7.41rem
      background:url(../../../../assets/images/oper/oper-2016/2016-1-6.jpg) no-repeat
      background-position: center
      background-size: 100% 100%
    .jd-1-bg7
      height:7.63rem
      background:url(../../../../assets/images/oper/oper-2016/2016-1-7.jpg) no-repeat
      background-position: center
      background-size: 100% 100%
    .jd-1-bg8
      height:4.88rem
      background:url(../../../../assets/images/oper/oper-2016/2016-1-8.jpg) no-repeat
      background-position: center
      background-size: 100% 100%
    .jd-1-bg9
      height:4.27rem
      background:url(../../../../assets/images/oper/oper-2016/2016-1-9.jpg) no-repeat
      background-position: center
      background-size: 100% 100%
    .jd-1-bg10
      height:4.25rem
      background:url(../../../../assets/images/oper/oper-2016/2016-1-10.jpg) no-repeat
      background-position: center
      background-size: 100% 100%
    .jd-1-bg11
      height:4.46rem
      background:url(../../../../assets/images/oper/oper-2016/2016-1-11.jpg) no-repeat
      background-position: center
      background-size: 100% 100%
</style>
