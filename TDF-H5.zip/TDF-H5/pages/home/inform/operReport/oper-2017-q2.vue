<template>
  <div class="jd-2-17">
    <td-header title="拓道金服2017年第er季度运营报告"/>
    <div class="oper-title"/>
    <div class="abo">
      <span class="abo-bg"/>
    </div>
    <div class="trend">
      <span class="trend-bg"/>
    </div>
    <div class="datas">
      <span class="datas-bg"/>
    </div>
    <div class="invest">
      <span class="invest-bg"/>
    </div>
    <div class="deadline">
      <span class="deadline-bg"/>
    </div>
    <div class="statistics">
      <span class="statistics-bg"/>
    </div>
    <div class="ranking">
      <span class="ranking-people"/>
      <span class="ranking-city"/>
    </div>
    <div class="invest-way">
      <span class="way-bg"/>
    </div>
    <div class="ratio">
      <span class="ratio-bg"/>
    </div>
    <div class="constellation">
      <span class="cons-bg"/>
    </div>
    <div class="welfare">
      <span class="welfare-title"/>
      <span class="w-1"/>
      <span class="w-2"/>
      <span class="w-3"/>
      <span class="w-4"/>
      <span class="w-5"/>
      <span class="w-6"/>
      <span class="w-7"/>
    </div>
    <div class="incident">
      <span class="incident-bg"/>
    </div>
    <div class="footer">
      <span class="footer-bg"/>
    </div>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2017年第二季度运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .jd-2-17
    padding-top: 0.88rem
    i
      color: $color-gray1
      font-weight: bold
    div
      background-color:#2257bf
      width:100%
      background-color:#1d4fb1
      border-bottom:4px solid #2758b9
      text-align:center
      span
        display:inline-block
        margin-top:0.85rem
    .oper-title
      height:3.7rem
      background:url(../../../../assets/images/oper/oper-2017-jd2/img1.png) no-repeat
      background-size:100% 100%
      border:none
    .abo
      height:4.73rem
      .abo-bg
        width:6.5rem
        height:2.98rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/img2.png) no-repeat
        background-size:100% 100%
    .trend
      height:5.55rem
      .trend-bg
        width:6.86rem
        height:3.75rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/img3.png) no-repeat
        background-size:100% 100%
    .datas
      height:7.03rem
      .datas-bg
        width:6.62rem
        height:5.36rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/img4.png) no-repeat
        background-size:100% 100%
    .invest
      height:4.96rem
      .invest-bg
        width:6.49rem
        height:3.32rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/img5.png) no-repeat
        background-size:100% 100%
    .deadline
      height:5.53rem
      .deadline-bg
        width:6.69rem
        height:3.89rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/img6.png) no-repeat
        background-size:100% 100%
    .statistics
      height:8.23rem
      .statistics-bg
        width:6.12rem
        height:6.57rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/img7.png) no-repeat
        background-size:100% 100%
    .ranking
      height:11.9rem
      .ranking-people
        width:6.5rem
        height:5.31rem
        margin-top:0.82rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/img8.png) no-repeat
        background-size:100% 100%
      .ranking-city
        width:6.49rem
        height:4.22rem
        margin-top:0.55rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/img9.png) no-repeat
        background-size:100% 100%
    .invest-way
      height:4.96rem
      .way-bg
        width:6.47rem
        height:3.35rem
        margin-top:0.8rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/img10.png) no-repeat
        background-size:100% 100%
    .ratio
      height:8.79rem
      .ratio-bg
        width:6.59rem
        height:7.15rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/img11.png) no-repeat
        background-size:100% 100%
    .constellation
      height:7.2rem
      .cons-bg
        width:4.41rem
        height:5.57rem
        margin-top:0.8rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/img12.png) no-repeat
        background-size:100% 100%
    .welfare
      height:25.18rem
      width:100%
      padding:0 11%
      overflow: hidden
      span
        margin-top:0.3rem
        float:left
      .welfare-title
        width:2.55rem
        height:0.52rem
        margin:0.83rem 27% 0 28%
        background:url(../../../../assets/images/oper/oper-2017-jd2/w-title.png) no-repeat
        background-size:100% 100%
      .w-1
        width:5.79rem
        height:2.95rem
        margin-top:0.6rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/w-1.png) no-repeat
        background-size:100% 100%
      .w-2
        width:5.78rem
        height:2.95rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/w-2.png) no-repeat
        background-size:100% 100%
      .w-3
        width:5.78rem
        height:2.95rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/w-3.png) no-repeat
        background-size:100% 100%
      .w-4
        width:5.78rem
        height:2.95rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/w-4.png) no-repeat
        background-size:100% 100%
      .w-5
        width:5.78rem
        height:2.94rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/w-5.png) no-repeat
        background-size:100% 100%
      .w-6
        width:5.78rem
        height:2.94rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/w-6.png) no-repeat
        background-size:100% 100%
      .w-7
        width:5.78rem
        height:2.94rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/w-7.png) no-repeat
        background-size:100% 100%
    .incident
      height:7.81rem
      border:none
      .incident-bg
        width:6.49rem
        height:6.18rem
        margin-top:0.82rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/img13.png) no-repeat
        background-size:100% 100%
    .footer
      height:4.55rem
      background-color:#2257bf
      .footer-bg
        width:4.13rem
        height:2.54rem
        margin-top:0.82rem
        background:url(../../../../assets/images/oper/oper-2017-jd2/footer.png) no-repeat
        background-size:100% 100%
</style>
