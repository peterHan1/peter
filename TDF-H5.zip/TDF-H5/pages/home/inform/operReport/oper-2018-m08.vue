<template>
  <div class="month-8">
    <td-header title="拓道金服2018年度8月份运营报告"/>
    <div class="month-8-banner"/>
    <div class="month-8-bg1"/>
    <div class="month-8-bg2"/>
    <div class="month-8-bg3"/>
    <div class="month-8-bg4"/>
    <div class="month-8-bg5"/>
    <div class="month-8-bg6"/>
    <div class="month-8-bg7"/>
    <div class="inform-charge"/>
    <div class="month-8-bg8"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2018年度8月份运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .month-8
    overflow:hidden
    padding-top: 0.88rem
    background-color: $color-white
    span
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      overflow: hidden
    .month-8-bg1
      height:2.88rem
      background:url(../../../../assets/images/oper/oper-2018-m8/img1.png) no-repeat
      background-size:100% 100%
    .month-8-bg2
      height:4.91rem
      background:url(../../../../assets/images/oper/oper-2018-m8/img2.png) no-repeat
      background-size:100% 100%
    .month-8-bg3
      height:8.92rem
      background:url(../../../../assets/images/oper/oper-2018-m8/img3.png) no-repeat
      background-size:100% 100%
    .month-8-bg4
      height:7.92rem
      background:url(../../../../assets/images/oper/oper-2018-m8/img4.png) no-repeat
      background-size:100% 100%
    .month-8-bg5
      height:7.99rem
      background:url(../../../../assets/images/oper/oper-2018-m8/img5.png) no-repeat
      background-size:100% 100%
    .month-8-bg6
      height:13.1rem
      background:url(../../../../assets/images/oper/oper-2018-m8/img6.png) no-repeat
      background-size:100% 100%
    .month-8-bg7
      height:10.82rem
      background:url(../../../../assets/images/oper/oper-2018-m8/img7.png) no-repeat
      background-size:100% 100%
    .month-8-bg8
      height:3.79rem
      background:url(../../../../assets/images/oper/oper-2018-m8/img8.png) no-repeat
      background-size:100% 100%
    .inform-charge
      height: 12.58rem
      background: url(../../../../assets/images/inform/inform-charge.jpg) no-repeat
      background-size: 100% 100%
</style>
