<template>
  <div class="year-2016">
    <td-header title="拓道金服2016年度运营报告"/>
    <div class="year-2016-bg1"/>
    <div class="year-2016-bg2"/>
    <div class="year-2016-bg3"/>
    <div class="year-2016-bg4"/>
    <div class="year-2016-bg5"/>
    <div class="year-2016-bg6"/>
    <div class="year-2016-bg7"/>
    <div class="year-2016-bg8"/>
    <div class="year-2016-bg9"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2016年度运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .year-2016
    overflow:hidden
    padding-top: 0.88rem
    background-color:$color-white
    span
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      overflow: hidden
    .year-2016-bg1
      height:2.88rem
      background:url(../../../../assets/images/oper/oper-2016year/2016year-1.png) no-repeat
      background-size:100% 100%
    .year-2016-bg2
      height:6.02rem
      background:url(../../../../assets/images/oper/oper-2016year/2016year-2.png) no-repeat
      background-size:100% 100%
    .year-2016-bg3
      height:15.07rem
      background:url(../../../../assets/images/oper/oper-2016year/2016year-3.png) no-repeat
      background-size:100% 100%
    .year-2016-bg4
      height:7.61rem
      background:url(../../../../assets/images/oper/oper-2016year/2016year-4.png) no-repeat
      background-size:100% 100%
    .year-2016-bg5
      height:10.91rem
      background:url(../../../../assets/images/oper/oper-2016year/2016year-5.png) no-repeat
      background-size:100% 100%
    .year-2016-bg6
      height:9.49rem
      background:url(../../../../assets/images/oper/oper-2016year/2016year-6.png) no-repeat
      background-size:100% 100%
    .year-2016-bg7
      height:10.53rem
      background:url(../../../../assets/images/oper/oper-2016year/2016year-7.png) no-repeat
      background-size:100% 100%
    .year-2016-bg8
      height:7.08rem
      background:url(../../../../assets/images/oper/oper-2016year/2016year-8.png) no-repeat
      background-size:100% 100%
    .year-2016-bg9
      height:3.95rem
      background:url(../../../../assets/images/oper/oper-2016year/2016year-9.png) no-repeat
      background-size:100% 100%
</style>
