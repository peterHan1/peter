<template>
  <div class="month-7">
    <td-header title="拓道金服2018年度7月份运营报告"/>
    <div class="month-7-bg1"/>
    <div class="month-7-bg2"/>
    <div class="month-7-bg3"/>
    <div class="month-7-bg4"/>
    <div class="month-7-bg5"/>
    <div class="month-7-bg6"/>
    <div class="month-7-bg7"/>
    <div class="inform-charge"/>
    <div class="month-7-bg8"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2018年度7月份运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .month-7
    overflow:hidden
    padding-top: 0.88rem
    background-color: $color-white
    span
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      overflow: hidden
    .month-7-bg1
      height:2.88rem
      background:url(../../../../assets/images/oper/oper-2018-m7/img1.png) no-repeat
      background-size:100% 100%
    .month-7-bg2
      height:4.94rem
      background:url(../../../../assets/images/oper/oper-2018-m7/img2.png) no-repeat
      background-size:100% 100%
    .month-7-bg3
      height:8.92rem
      background:url(../../../../assets/images/oper/oper-2018-m7/img3.png) no-repeat
      background-size:100% 100%
    .month-7-bg4
      height:7.89rem
      background:url(../../../../assets/images/oper/oper-2018-m7/img4.png) no-repeat
      background-size:100% 100%
    .month-7-bg5
      height:8.01rem
      background:url(../../../../assets/images/oper/oper-2018-m7/img5.png) no-repeat
      background-size:100% 100%
    .month-7-bg6
      height:13.11rem
      background:url(../../../../assets/images/oper/oper-2018-m7/img6.png) no-repeat
      background-size:100% 100%
    .month-7-bg7
      height:10.23rem
      background:url(../../../../assets/images/oper/oper-2018-m7/img7.png) no-repeat
      background-size:100% 100%
    .month-7-bg8
      height:3.56rem
      background:url(../../../../assets/images/oper/oper-2018-m7/img8.png) no-repeat
      background-size:100% 100%
    .inform-charge
      height: 12.58rem
      background: url(../../../../assets/images/inform/inform-charge.jpg) no-repeat
      background-size: 100% 100%
</style>
