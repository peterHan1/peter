<template>
  <div class="m-10">
    <td-header title="拓道金服2017年度10月份运营报告"/>
    <div class="oper-title"/>
    <div>
      <span class="abos-bg"/>
    </div>
    <div>
      <span class="trends-bg"/>
    </div>
    <div >
      <span class="stands-out"/>
    </div>
    <div>
      <span class="datass-bg"/>
    </div>
    <div>
      <span class="invests-bg"/>
    </div>
    <div>
      <span class="deadlines-bg"/>
    </div>
    <div>
      <span class="statisticss-bg"/>
    </div>
    <div>
      <span class="rankings-city"/>
    </div>
    <div>
      <span class="ratios-bg"/>
    </div>
    <div>
      <span class="conss-bg"/>
    </div>
    <div>
      <span class="incidents-bg"/>
    </div>
    <div>
      <span class="welfare-bg"/>
    </div>
    <div>
      <span class="news-bg"/>
    </div>
    <div class="footer"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2017年度10月份运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .m-10
    padding-top: 0.88rem
    i
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      background-color:$color-white
      text-align:center
      overflow: hidden
      span
        display:inline-block
        width:100%
        float: left
    .oper-title
      height:3.83rem
      background:url(../../../../assets/images/oper/oper-2017-m10/m-10-banner.png) no-repeat
      background-size:100% 100%
    .abos-bg
      height:7.51rem
      background:url(../../../../assets/images/oper/oper-2017-m10/m-10-general1.png) no-repeat
      background-size:100% 100%
    .trends-bg
      height:5.53rem
      background:url(../../../../assets/images/oper/oper-2017-m10/m-10-general2.png) no-repeat
      background-size:100% 100%
    .stands-out
      height:9.33rem
      background:url(../../../../assets/images/oper/oper-2017-m10/m-10-general3.png) no-repeat
      background-size:100% 100%
    .datass-bg
      height:11.44rem
      background:url(../../../../assets/images/oper/oper-2017-m10/m-10-general4.png) no-repeat
      background-size:100% 100%
    .invests-bg
      height:6.16rem
      background:url(../../../../assets/images/oper/oper-2017-m10/m-10-general5.png) no-repeat
      background-size:100% 100%
    .deadlines-bg
      height:5.31rem
      background:url(../../../../assets/images/oper/oper-2017-m10/m-10-general6.png) no-repeat
      background-size:100% 100%
    .statisticss-bg
      height: 5.31rem
      background: url(../../../../assets/images/oper/oper-2017-m10/m-10-general7.png) no-repeat
      background-size: 100% 100%
    .rankings-city
      height:5.28rem
      margin-top:0
      background:url(../../../../assets/images/oper/oper-2017-m10/m-10-general8.png) no-repeat
      background-size: 100% 100%
    .ratios-bg
      height: 11.42rem
      background: url(../../../../assets/images/oper/oper-2017-m10/m-10-general9.png) no-repeat
      background-size: 100% 100%
    .conss-bg
      height: 8.48rem
      background: url(../../../../assets/images/oper/oper-2017-m10/m-10-general10.png) no-repeat
      background-size: 100% 100%
    .incidents-bg
      height:7.72rem
      background: url(../../../../assets/images/oper/oper-2017-m10/m-10-general11.png) no-repeat
      background-size: 100% 100%
    .welfare-bg
      height:8.06rem
      background: url(../../../../assets/images/oper/oper-2017-m10/m-10-general12.png) no-repeat
      background-size: 100% 100%
    .news-bg
      height:5.25rem
      background: url(../../../../assets/images/oper/oper-2017-m10/m-10-general13.png) no-repeat
      background-size: 100% 100%
    .footer
      height:6.07rem
      background: url(../../../../assets/images/oper/oper-2017-m10/m-10-footer.png) no-repeat
      background-size: 100% 100%
</style>
