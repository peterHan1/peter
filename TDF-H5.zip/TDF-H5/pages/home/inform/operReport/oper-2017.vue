<template>
  <div class="year-2017">
    <td-header title="拓道金服2017年度运营报告"/>
    <div>
      <span class="year-2017-bg1"/>
    </div>
    <div>
      <span class="year-2017-bg2"/>
    </div>
    <div >
      <span class="year-2017-bg3"/>
    </div>
    <div>
      <span class="year-2017-bg4"/>
    </div>
    <div>
      <span class="year-2017-bg5"/>
    </div>
    <div>
      <span class="year-2017-bg6"/>
    </div>
    <div>
      <span class="year-2017-bg7"/>
    </div>
    <div>
      <span class="year-2017-bg8"/>
    </div>
    <div>
      <span class="year-2017-bg9"/>
    </div>
    <div>
      <span class="year-2017-bg10"/>
    </div>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2017年度运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .year-2017
    overflow:hidden
    padding-top: 0.88rem
    background-color: $color-white
    i
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      overflow: hidden
    div span
      display:inline-block
      width:100%
    .year-2017-bg1
      height:2.93rem
      background:url(../../../../assets/images/oper/oper-2017year/2017year-1.png) no-repeat
      background-size:100% 100%
    .year-2017-bg2
      height:5.97rem
      background:url(../../../../assets/images/oper/oper-2017year/2017year-2.png) no-repeat
      background-size:100% 100%
    .year-2017-bg3
      height:5.49rem
      background:url(../../../../assets/images/oper/oper-2017year/2017year-3.png) no-repeat
      background-size:100% 100%
    .year-2017-bg4
      height:9.58rem
      background:url(../../../../assets/images/oper/oper-2017year/2017year-4.png) no-repeat
      background-size:100% 100%
    .year-2017-bg5
      height:15.23rem
      background:url(../../../../assets/images/oper/oper-2017year/2017year-5.png) no-repeat
      background-size:100% 100%
    .year-2017-bg6
      height:10.91rem
      background:url(../../../../assets/images/oper/oper-2017year/2017year-6.png) no-repeat
      background-size:100% 100%
    .year-2017-bg7
      height:9.49rem
      background:url(../../../../assets/images/oper/oper-2017year/2017year-7.png) no-repeat
      background-size:100% 100%
    .year-2017-bg8
      height:10.52rem
      background:url(../../../../assets/images/oper/oper-2017year/2017year-8.png) no-repeat
      background-size:100% 100%
    .year-2017-bg9
      height:7.07rem
      background:url(../../../../assets/images/oper/oper-2017year/2017year-9.png) no-repeat
      background-size:100% 100%
    .year-2017-bg10
      height:3.39rem
      background:url(../../../../assets/images/oper/oper-2017year/2017year-10.png) no-repeat
      background-size:100% 100%
</style>
