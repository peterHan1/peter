<template>
  <div class="month-5">
    <td-header title="拓道金服2018年度5月份运营报告"/>
    <div class="abos-bg"/>
    <div class="trends-bg"/>
    <div class="stands-out"/>
    <div class="datass-bg"/>
    <div class="invests-bg"/>
    <div class="deadlines-bg"/>
    <div class="constellation-bg"/>
    <div class="incidents-bg"/>
    <div class="footer-bg"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2018年度5月份运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .month-5
    overflow:hidden
    padding-top: 0.88rem
    background-color: $color-white
    span
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      overflow: hidden
    .abos-bg
      height:2.86rem
      background:url(../../../../assets/images/oper/oper-2018-m5/img1.png) no-repeat
      background-size:100% 100%
    .trends-bg
      height:4.94rem
      background:url(../../../../assets/images/oper/oper-2018-m5/img2.png) no-repeat
      background-size:100% 100%
    .stands-out
      height:8.91rem
      background:url(../../../../assets/images/oper/oper-2018-m5/img3.png) no-repeat
      background-size:100% 100%
    .datass-bg
      height:7.89rem
      background:url(../../../../assets/images/oper/oper-2018-m5/img4.png) no-repeat
      background-size:100% 100%
    .invests-bg
      height:8.01rem
      background:url(../../../../assets/images/oper/oper-2018-m5/img5.png) no-repeat
      background-size:100% 100%
    .deadlines-bg
      height:13.11rem
      background:url(../../../../assets/images/oper/oper-2018-m5/img6.png) no-repeat
      background-size:100% 100%
    .constellation-bg
      height:3rem
      background:url(../../../../assets/images/oper/oper-2018-m5/img7.png) no-repeat
      background-size:100% 100%
    .incidents-bg
      height:9.95rem
      background:url(../../../../assets/images/oper/oper-2018-m5/img8.png) no-repeat
      background-size:100% 100%
    .footer-bg
      height:4.26rem
      background:url(../../../../assets/images/oper/oper-2018-m5/img9.png) no-repeat
      background-size:100% 100%
</style>
