<template>
  <div class="jd-2-16">
    <td-header title="拓道金服2016年第二季度运营报告"/>
    <div>
      <span class="jd-2-bg1"/>
    </div>
    <div>
      <span class="jd-2-bg2"/>
    </div>
    <div >
      <span class="jd-2-bg3"/>
    </div>
    <div>
      <span class="jd-2-bg4"/>
    </div>
    <div>
      <span class="jd-2-bg5"/>
    </div>
    <div>
      <span class="jd-2-bg6"/>
    </div>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2016第二季度运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .jd-2-16
    overflow:hidden
    padding-top: 0.88rem
    background-color:$color-white
    i
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      text-align:center
      overflow: hidden
      font-size: 0
      span
        display:inline-block
        width:100%
    .jd-2-bg1
      height:12.66rem
      background:url(../../../../assets/images/oper/oper-2016/2016-2-1.jpg) no-repeat
      background-size:100% 100%
    .jd-2-bg2
      height:12.9rem
      background:url(../../../../assets/images/oper/oper-2016/2016-2-2.jpg) no-repeat
      background-size:100% 100%
    .jd-2-bg3
      height:14.88rem
      background:url(../../../../assets/images/oper/oper-2016/2016-2-3.jpg) no-repeat
      background-size:100% 100%
    .jd-2-bg4
      height:15.24rem
      background:url(../../../../assets/images/oper/oper-2016/2016-2-4.jpg) no-repeat
      background-size:100% 100%
    .jd-2-bg5
      height:13.74rem
      background:url(../../../../assets/images/oper/oper-2016/2016-2-5.jpg) no-repeat
      background-size:100% 100%
    .jd-2-bg6
      height:12.08rem
      background:url(../../../../assets/images/oper/oper-2016/2016-2-6.jpg) no-repeat
      background-size:100% 100%
</style>
