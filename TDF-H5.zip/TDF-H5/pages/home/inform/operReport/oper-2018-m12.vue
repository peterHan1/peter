<template>
  <div class="month-12">
    <td-header title="拓道金服2018年度12月份运营报告"/>
    <div class="month-12-banner"/>
    <div class="month-12-bg1"/>
    <div class="month-12-bg2"/>
    <div class="month-12-bg3"/>
    <div class="month-12-bg4"/>
    <div class="month-12-bg5"/>
    <div class="month-12-bg6"/>
    <div class="month-12-bg7"/>
    <div class="compliance-bg"/>
    <div class="inform-charge"/>
    <div class="month-12-bg8"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2018年度12月份运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .month-12
    overflow:hidden
    padding-top: 0.88rem
    background-color: $color-white
    span
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      overflow: hidden
    .month-12-banner
      height:2.87rem
      background:url(../../../../assets/images/oper/oper-2018-m12/img1.png) no-repeat
      background-size:100% 100%
    .month-12-bg1
      height:6.04rem
      background:url(../../../../assets/images/oper/oper-2018-m12/img2.png) no-repeat
      background-size:100% 100%
    .month-12-bg2
      height:15.08rem
      background:url(../../../../assets/images/oper/oper-2018-m12/img3.png) no-repeat
      background-size:100% 100%
    .month-12-bg3
      height:15.24rem
      background:url(../../../../assets/images/oper/oper-2018-m12/img4.png) no-repeat
      background-size:100% 100%
    .month-12-bg4
      height:10.93rem
      background:url(../../../../assets/images/oper/oper-2018-m12/img5.png) no-repeat
      background-size:100% 100%
    .month-12-bg5
      height:9.5rem
      background:url(../../../../assets/images/oper/oper-2018-m12/img6.png) no-repeat
      background-size:100% 100%
    .month-12-bg6
      height:10.52rem
      background:url(../../../../assets/images/oper/oper-2018-m12/img7.png) no-repeat
      background-size:100% 100%
    .month-12-bg7
      height:7.09rem
      background:url(../../../../assets/images/oper/oper-2018-m12/img8.png) no-repeat
      background-size:100% 100%
    .month-12-bg8
      height:3.98rem
      background:url(../../../../assets/images/oper/oper-2018-m12/img9.png) no-repeat
      background-size:100% 100%
    .inform-charge
      height: 12.58rem
      background: url(../../../../assets/images/inform/inform-charge.jpg) no-repeat
      background-size: 100% 100%
</style>
