<template>
  <div class="m-8">
    <td-header title="拓道金服2017年度8月份运营报告"/>
    <div class="oper-title"/>
    <div>
      <span class="abos-bg"/>
    </div>
    <div>
      <span class="trends-bg"/>
    </div>
    <div >
      <span class="stands-out"/>
    </div>
    <div class="datas">
      <span class="datass-bg"/>
    </div>
    <div>
      <span class="invests-bg"/>
    </div>
    <div>
      <span class="deadlines-bg"/>
    </div>
    <div>
      <span class="statisticss-bg"/>
    </div>
    <div class="ranking">
      <span class="rankings-city"/>
    </div>
    <div>
      <span class="ratios-bg"/>
    </div>
    <div>
      <span class="conss-bg"/>
    </div>
    <div class="incident">
      <span class="incidents-bg"/>
    </div>
    <div class="footer"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2017年度8月份运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .m-8
    background-color: $color-white
    padding-top: 0.88rem
    i
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      background-color:$color-white
      text-align:center
    div span
      display:inline-block
      margin-top:0.9rem
    .oper-title
      height:3.26rem
      background:url(../../../../assets/images/oper/oper-2017-m8/m-8-banner.png) no-repeat
      background-size:100% 100%
    .abos-bg
      margin-top:0.7rem
      width:6.49rem
      height:4.25rem
      background:url(../../../../assets/images/oper/oper-2017-m8/m-8-general1.png) no-repeat
      background-size:100% 100%
    .trends-bg
      width:6.51rem
      height:1.88rem
      background:url(../../../../assets/images/oper/oper-2017-m8/m-8-general2.png) no-repeat
      background-size:100% 100%
    .stands-out
      width:6.61rem
      height:3.01rem
      background:url(../../../../assets/images/oper/oper-2017-m8/m-8-general3.png) no-repeat
      background-size:100% 100%
    .datas
      height:16.9rem
      background-color:#fff
      margin-top:0.9rem
    .datass-bg
      margin-top:0
      height:16.9rem
      width:7.5rem
      background:url(../../../../assets/images/oper/oper-2017-m8/m-8-general4.png) no-repeat
      background-size:100% 100%
    .invests-bg
      width:6.5rem
      height:3rem
      background:url(../../../../assets/images/oper/oper-2017-m8/m-8-general5.png) no-repeat
      background-size:100% 100%
    .deadlines-bg
      margin-top:1.4rem
      width:6.5rem
      height:3.08rem
      background:url(../../../../assets/images/oper/oper-2017-m8/m-8-general6.png) no-repeat
      background-size:100% 100%
    .statisticss-bg
      margin-top:1.4rem
      width: 5.1rem
      height: 3.51rem
      background: url(../../../../assets/images/oper/oper-2017-m8/m-8-general7.png) no-repeat
      background-size: 100% 100%
    .ranking
      height:11.6rem
      background-color:#fff
      margin-top:1.7rem
    .rankings-city
      width:6.53rem
      height:10.3rem
      margin-top:0
      background:url(../../../../assets/images/oper/oper-2017-m8/m-8-general8.png) no-repeat
      background-size: 100% 100%
    .ratios-bg
      margin-top:0.8rem
      width: 6.75rem
      height: 6.61rem
      background: url(../../../../assets/images/oper/oper-2017-m8/m-8-general9.png) no-repeat
      background-size: 100% 100%
    .conss-bg
      width: 6.4rem
      height: 6.9rem
      background: url(../../../../assets/images/oper/oper-2017-m8/m-8-general10.png) no-repeat
      background-size: 100% 100%
    .incident
      height:13.53rem
      margin-top:0.9rem
    .incidents-bg
      width:6.5rem
      height:13.03rem
      margin-top:0
      background: url(../../../../assets/images/oper/oper-2017-m8/m-8-general11.png) no-repeat
      background-size: 100% 100%
    .footer
      height:3.97rem
      background: url(../../../../assets/images/oper/oper-2017-m8/m-8-footer.png) no-repeat
      background-size: 100% 100%
</style>
