<template>
  <div class="month-9">
    <td-header title="拓道金服2018年度9月份运营报告"/>
    <div class="month-9-banner"/>
    <div class="month-9-bg1"/>
    <div class="month-9-bg2"/>
    <div class="month-9-bg3"/>
    <div class="month-9-bg4"/>
    <div class="month-9-bg5"/>
    <div class="month-9-bg6"/>
    <div class="month-9-bg7"/>
    <div class="month-9-bg8"/>
    <div class="month-9-bg9"/>
    <div class="month-9-bg10"/>
    <div class="inform-charge"/>
    <div class="month-9-bg11"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2018年度9月份运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .month-9
    overflow:hidden
    padding-top: 0.88rem
    background-color: $color-white
    span
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      overflow: hidden
    .month-9-banner
      height:2.86rem
      background:url(../../../../assets/images/oper/oper-2018-m9/img1.png) no-repeat
      background-size:100% 100%
    .month-9-bg1
      height:5.85rem
      background:url(../../../../assets/images/oper/oper-2018-m9/img2.png) no-repeat
      background-size:100% 100%
    .month-9-bg2
      height:5.78rem
      background:url(../../../../assets/images/oper/oper-2018-m9/img3.png) no-repeat
      background-size:100% 100%
    .month-9-bg3
      height:7.89rem
      background:url(../../../../assets/images/oper/oper-2018-m9/img4.png) no-repeat
      background-size:100% 100%
    .month-9-bg4
      height:9.06rem
      background:url(../../../../assets/images/oper/oper-2018-m9/img5.png) no-repeat
      background-size:100% 100%
    .month-9-bg5
      height:6.46rem
      background:url(../../../../assets/images/oper/oper-2018-m9/img6.png) no-repeat
      background-size:100% 100%
    .month-9-bg6
      height:4.71rem
      background:url(../../../../assets/images/oper/oper-2018-m9/img7.png) no-repeat
      background-size:100% 100%
    .month-9-bg7
      height:8.47rem
      background:url(../../../../assets/images/oper/oper-2018-m9/img8.png) no-repeat
      background-size:100% 100%
    .month-9-bg8
      height:7.23rem
      background:url(../../../../assets/images/oper/oper-2018-m9/img9.png) no-repeat
      background-size:100% 100%
    .month-9-bg9
      height:4.25rem
      background:url(../../../../assets/images/oper/oper-2018-m9/img10.png) no-repeat
      background-size:100% 100%
    .month-9-bg10
      height:10.97rem
      background:url(../../../../assets/images/oper/oper-2018-m9/img11.png) no-repeat
      background-size:100% 100%
    .month-9-bg11
      height:3.59rem
      background:url(../../../../assets/images/oper/oper-2018-m9/img12.png) no-repeat
      background-size:100% 100%
    .inform-charge
      height: 12.58rem
      background: url(../../../../assets/images/inform/inform-charge.jpg) no-repeat
      background-size: 100% 100%
</style>
