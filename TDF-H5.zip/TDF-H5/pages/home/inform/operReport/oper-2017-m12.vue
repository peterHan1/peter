<template>
  <div class="m-12">
    <td-header title="拓道金服2017年度12月份运营报告"/>
    <div class="oper-title"/>
    <div class="abos">
      <span class="abos-bg"/>
    </div>
    <div>
      <span class="trends-bg"/>
    </div>
    <div >
      <span class="stands-out"/>
    </div>
    <div>
      <span class="datass-bg"/>
    </div>
    <div>
      <span class="invests-bg"/>
    </div>
    <div>
      <span class="deadlines-bg"/>
    </div>
    <div>
      <span class="statisticss-bg"/>
    </div>
    <div>
      <span class="rankings-city"/>
    </div>
    <div>
      <span class="ratios-bg"/>
    </div>
    <div>
      <span class="conss-bg"/>
    </div>
    <div>
      <span class="incidents-bg"/>
    </div>
    <div class="footer"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2017年度12月份运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .m-12
    overflow:hidden
    padding-top: 0.88rem
    background: -webkit-linear-gradient(#3f71fb, #3b6afb)
    background: -o-linear-gradient(#3f71fb, #3b6afb)
    background: -moz-linear-gradient(#3f71fb, #3b6afb)
    background: linear-gradient(#3f71fb, #3b6afb)
    i
      color: $color-gray1
      font-weight: bold
    div
      width:7.3rem
      text-align:center
      overflow: hidden
      margin:0.1rem auto 0
    div span
      display:inline-block
      width:100%
      float: left
      border-radius:3px
    .oper-title
      width:100%
      margin:0
      height:3.4rem
      background:url(../../../../assets/images/oper/oper-2017-m12/m-12-banner.png) no-repeat
      background-size:100% 100%
    .abos
      width:100%
      margin:0
    .abos-bg
      height:8.75rem
      border-radius:0
      background:url(../../../../assets/images/oper/oper-2017-m12/m-12-general1.png) no-repeat
      background-size:100% 100%
    .trends-bg
      height:3.53rem
      background:url(../../../../assets/images/oper/oper-2017-m12/m-12-general2.png) no-repeat
      background-size:100% 100%
    .stands-out
      height:8.22rem
      background:url(../../../../assets/images/oper/oper-2017-m12/m-12-general3.png) no-repeat
      background-size:100% 100%
    .datass-bg
      height:8.02rem
      background:url(../../../../assets/images/oper/oper-2017-m12/m-12-general4.png) no-repeat
      background-size:100% 100%
    .invests-bg
      height:6.24rem
      background:url(../../../../assets/images/oper/oper-2017-m12/m-12-general5.png) no-repeat
      background-size:100% 100%
    .deadlines-bg
      height:4.02rem
      background:url(../../../../assets/images/oper/oper-2017-m12/m-12-general6.png) no-repeat
      background-size:100% 100%
    .statisticss-bg
      height: 7.85rem
      background: url(../../../../assets/images/oper/oper-2017-m12/m-12-general7.png) no-repeat
      background-size: 100% 100%
    .rankings-city
      height:7.19rem
      margin-top:0
      background:url(../../../../assets/images/oper/oper-2017-m12/m-12-general8.png) no-repeat
      background-size: 100% 100%
    .ratios-bg
      height: 4.46rem
      background: url(../../../../assets/images/oper/oper-2017-m12/m-12-general9.png) no-repeat
      background-size: 100% 100%
    .conss-bg
      height: 9.79rem
      background: url(../../../../assets/images/oper/oper-2017-m12/m-12-general10.png) no-repeat
      background-size: 100% 100%
    .incidents-bg
      height:10.29rem
      background: url(../../../../assets/images/oper/oper-2017-m12/m-12-general11.png) no-repeat
      background-size: 100% 100%
    .footer
      width:3.88rem
      margin:0.6rem auto
      height:2.5rem
      background: url(../../../../assets/images/oper/oper-2017-m12/m-12-footer.png) no-repeat
      background-size: 100% 100%
</style>
