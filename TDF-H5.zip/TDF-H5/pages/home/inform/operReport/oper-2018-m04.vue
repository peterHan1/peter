<template>
  <div class="month-4">
    <td-header title="拓道金服2018年度4月份运营报告"/>
    <div class="abos-bg"/>
    <div class="trends-bg"/>
    <div class="stands-out"/>
    <div class="datass-bg"/>
    <div class="invests-bg"/>
    <div class="deadlines-bg"/>
    <div class="constellation-bg"/>
    <div class="footer-bg"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2018年度4月份运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .month-4
    overflow:hidden
    padding-top: 0.88rem
    background-color: $color-white
    span
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      overflow: hidden
    .abos-bg
      height:2.86rem
      background:url(../../../../assets/images/oper/oper-2018-m4/img1.png) no-repeat
      background-size:100% 100%
    .trends-bg
      height:4.94rem
      background:url(../../../../assets/images/oper/oper-2018-m4/img2.png) no-repeat
      background-size:100% 100%
    .stands-out
      height:8.92rem
      background:url(../../../../assets/images/oper/oper-2018-m4/img3.png) no-repeat
      background-size:100% 100%
    .datass-bg
      height:7.89rem
      background:url(../../../../assets/images/oper/oper-2018-m4/img4.png) no-repeat
      background-size:100% 100%
    .invests-bg
      height:8rem
      background:url(../../../../assets/images/oper/oper-2018-m4/img5.png) no-repeat
      background-size:100% 100%
    .deadlines-bg
      height:13.1rem
      background:url(../../../../assets/images/oper/oper-2018-m4/img6.png) no-repeat
      background-size:100% 100%
    .constellation-bg
      height:2.92rem
      background:url(../../../../assets/images/oper/oper-2018-m4/img7.png) no-repeat
      background-size:100% 100%
    .footer-bg
      height:2.87rem
      background:url(../../../../assets/images/oper/oper-2018-m4/img8.png) no-repeat
      background-size:100% 100%
</style>
