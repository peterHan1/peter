<template>
  <div class="m-7">
    <td-header title="拓道金服2017年度7月份运营报告"/>
    <div class="oper-title"/>
    <div class="abo">
      <span class="abo-bg"/>
    </div>
    <div class="trend">
      <span class="trend-bg"/>
    </div>
    <div class="datas">
      <span class="datas-bg"/>
      <span class="dataf-bg"/>
    </div>
    <div class="invest">
      <span class="invest-bg"/>
    </div>
    <div class="deadline">
      <span class="deadline-bg"/>
    </div>
    <div class="statistics">
      <span class="statistics-bg"/>
    </div>
    <div class="ranking">
      <span class="ranking-people"/>
      <span class="ranking-city"/>
    </div>
    <div class="ratio">
      <span class="ratio-bg"/>
    </div>
    <div class="constellation">
      <span class="cons-bg"/>
    </div>
    <div class="incident">
      <span class="incident-bg"/>
    </div>
    <div class="footer"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2017年度7月份运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .m-7
    padding-top: 0.88rem
    i
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      background-color:$color-white
      text-align:center
      span
        display:inline-block
        margin-top:0.9rem
    .oper-title
      height:3.7rem
      background:url(../../../../assets/images/oper/oper-2017-m7/m-7-banner.png) no-repeat
      background-size:100% 100%
      border:none
    .abo
      height:6rem
      .abo-bg
        width:6.52rem
        height:4.25rem
        background:url(../../../../assets/images/oper/oper-2017-m7/m-7-general1.png) no-repeat
        background-size:100% 100%
    .trend
      height:3.66rem
      .trend-bg
        width:6.51rem
        height:1.88rem
        background:url(../../../../assets/images/oper/oper-2017-m7/m-7-general2.png) no-repeat
        background-size:100% 100%
    .datas
      height:18.29rem
      background-color:#f7fdff
      .datas-bg
        width:6.64rem
        height:9.78rem
        background:url(../../../../assets/images/oper/oper-2017-m7/m-7-general3.png) no-repeat
        background-size:100% 100%
      .dataf-bg
        width:6.51rem
        height:4.93rem
        margin-top:1.6rem
        background:url(../../../../assets/images/oper/oper-2017-m7/m-7-general4.png) no-repeat
        background-size:100% 100%
    .invest
      height:4.8rem
      .invest-bg
        width:6.49rem
        height:3rem
        background:url(../../../../assets/images/oper/oper-2017-m7/m-7-general5.png) no-repeat
        background-size:100% 100%
    .deadline
      height:4.85rem
      .deadline-bg
        width:6.5rem
        height:3.08rem
        background:url(../../../../assets/images/oper/oper-2017-m7/m-7-general6.png) no-repeat
        background-size:100% 100%
    .statistics
      height:5.4rem
      .statistics-bg
        width:6.49rem
        height:3.52rem
        background:url(../../../../assets/images/oper/oper-2017-m7/m-7-general7.png) no-repeat
        background-size:100% 100%
    .ranking
      height:19.92rem
      background-color:#f7fdff
      .ranking-people
        width:6.54rem
        height:5.77rem
        background:url(../../../../assets/images/oper/oper-2017-m7/m-7-general8.png) no-repeat
        background-size:100% 100%
      .ranking-city
        width:6.53rem
        height:10.61rem
        margin-top:1.7rem
        background:url(../../../../assets/images/oper/oper-2017-m7/m-7-general9.png) no-repeat
        background-size:100% 100%
    .ratio
      height:8.39rem
      .ratio-bg
        width:6.78rem
        height:6.61rem
        background:url(../../../../assets/images/oper/oper-2017-m7/m-7-general10.png) no-repeat
        background-size:100% 100%
    .constellation
      height:8.68rem
      .cons-bg
        width:6.5rem
        height:6.9rem
        background:url(../../../../assets/images/oper/oper-2017-m7/m-7-general11.png) no-repeat
        background-size:100% 100%
    .incident
      height:5.78rem
      .incident-bg
        width:6.51rem
        height:3.6rem
        background:url(../../../../assets/images/oper/oper-2017-m7/m-7-general12.png) no-repeat
        background-size:100% 100%
    .footer
      height:4.55rem
      height:4.52
      background:url(../../../../assets/images/oper/oper-2017-m7/m-7-footer.png) no-repeat
      background-size:100% 100%
</style>
