<template>
  <div class="jd-3-17">
    <td-header title="拓道金服2017年第三季度运营报告"/>
    <div class="oper-title"/>
    <div>
      <span class="abos-bg"/>
    </div>
    <div>
      <span class="trends-bg"/>
    </div>
    <div >
      <span class="stands-out"/>
    </div>
    <div>
      <span class="datass-bg"/>
    </div>
    <div>
      <span class="invests-bg"/>
    </div>
    <div>
      <span class="deadlines-bg"/>
    </div>
    <div>
      <span class="statisticss-bg"/>
    </div>
    <div>
      <span class="rankings-city"/>
    </div>
    <div>
      <span class="ratios-bg"/>
    </div>
    <div>
      <span class="conss-bg"/>
    </div>
    <div>
      <span class="incident-bg"/>
    </div>
    <div>
      <span class="incidents-bg"/>
    </div>
    <div class="footer"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2017年第三季度运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .jd-3-17
    padding-top: 0.88rem
    i
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      background-color: $color-white
      text-align:center
      span
        display:inline-block
        margin-top:1.1rem
    .oper-title
      height:3.58rem
      background:url(../../../../assets/images/oper/oper-2017-jd3/banner.png) no-repeat
      background-size:100% 100%
    .abos-bg
      margin-top:0.7rem
      width:6rem
      height:8.21rem
      background:url(../../../../assets/images/oper/oper-2017-jd3/general1.png) no-repeat
      background-size:100% 100%
    .trends-bg
      width:6.9rem
      height:3.24rem
      background:url(../../../../assets/images/oper/oper-2017-jd3/general2.png) no-repeat
      background-size:100% 100%
    .stands-out
      width:6.65rem
      height:7.81rem
      background:url(../../../../assets/images/oper/oper-2017-jd3/general3.png) no-repeat
      background-size:100% 100%
    .datass-bg
      height:11.36rem
      width:7.14rem
      background:url(../../../../assets/images/oper/oper-2017-jd3/general4.png) no-repeat
      background-size:100% 100%
    .invests-bg
      width:6.92rem
      height:4.42rem
      background:url(../../../../assets/images/oper/oper-2017-jd3/general5.png) no-repeat
      background-size:100% 100%
    .deadlines-bg
      width:6.5rem
      height:6.22rem
      background:url(../../../../assets/images/oper/oper-2017-jd3/general6.png) no-repeat
      background-size:100% 100%
    .statisticss-bg
      width: 6.75rem
      height: 3.88rem
      background: url(../../../../assets/images/oper/oper-2017-jd3/general7.png) no-repeat
      background-size: 100% 100%
    .rankings-city
      width:6.87rem
      height:8.63rem
      background:url(../../../../assets/images/oper/oper-2017-jd3/general8.png) no-repeat
      background-size: 100% 100%
    .ratios-bg
      width: 6.88rem
      height: 6.9rem
      background: url(../../../../assets/images/oper/oper-2017-jd3/general9.png) no-repeat
      background-size: 100% 100%
    .conss-bg
      width: 6.8rem
      height: 3.25rem
      background: url(../../../../assets/images/oper/oper-2017-jd3/general10.png) no-repeat
      background-size: 100% 100%
    .incident-bg
      width:5.2rem
      height:14.49rem
      background: url(../../../../assets/images/oper/oper-2017-jd3/general11.png) no-repeat
      background-size: 100% 100%
    .incidents-bg
      width:6.91rem
      height:10.11rem
      background: url(../../../../assets/images/oper/oper-2017-jd3/general12.png) no-repeat
      background-size: 100% 100%
    .footer
      margin-top:0.4rem
      height:4.49rem
      background: url(../../../../assets/images/oper/oper-2017-jd3/footer-bg.png) no-repeat
      background-size: 100% 100%
</style>
