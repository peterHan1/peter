<template>
  <div class="month-2">
    <td-header title="拓道金服2018年度2月份运营报告"/>
    <div class="abos-bg"/>
    <div class="trends-bg"/>
    <div class="stands-out"/>
    <div class="datass-bg"/>
    <div class="invests-bg"/>
    <div class="deadlines-bg"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2018年度2月份运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .month-2
    overflow:hidden
    padding-top: 0.88rem
    background-color: $color-white
    span
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      overflow: hidden
    .abos-bg
      height:7.53rem
      background:url(../../../../assets/images/oper/oper-2018-m2/img1.png) no-repeat
      background-size:100% 100%
    .trends-bg
      height:9.34rem
      background:url(../../../../assets/images/oper/oper-2018-m2/img2.png) no-repeat
      background-size:100% 100%
    .stands-out
      height:12.35rem
      background:url(../../../../assets/images/oper/oper-2018-m2/img3.png) no-repeat
      background-size:100% 100%
    .datass-bg
      height:11.23rem
      background:url(../../../../assets/images/oper/oper-2018-m2/img4.png) no-repeat
      background-size:100% 100%
    .invests-bg
      height:8rem
      background:url(../../../../assets/images/oper/oper-2018-m2/img5.png) no-repeat
      background-size:100% 100%
    .deadlines-bg
      height:11.01rem
      background:url(../../../../assets/images/oper/oper-2018-m2/img6.png) no-repeat
      background-size:100% 100%
</style>
