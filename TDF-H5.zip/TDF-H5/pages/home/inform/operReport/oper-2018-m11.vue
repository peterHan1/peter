<template>
  <div class="month-11">
    <td-header title="拓道金服2018年度11月份运营报告"/>
    <div class="month-11-banner"/>
    <div class="month-11-bg1"/>
    <div class="month-11-bg2"/>
    <div class="month-11-bg3"/>
    <div class="month-11-bg4"/>
    <div class="month-11-bg5"/>
    <div class="month-11-bg6"/>
    <div class="month-11-bg7"/>
    <div class="month-11-bg8"/>
    <div class="compliance-bg"/>
    <div class="inform-charge"/>
    <div class="month-11-bg9"/>
  </div>
</template>
<script>
export default {
  metaInfo: {
    title: '拓道金服2018年度11月份运营报告'
  },
  data() {
    return {}
  }
}
</script>
<style lang="stylus" scoped>
  .month-11
    overflow:hidden
    padding-top: 0.88rem
    background-color: $color-white
    span
      color: $color-gray1
      font-weight: bold
    div
      width:100%
      overflow: hidden
    .month-11-banner
      height:2.88rem
      background:url(../../../../assets/images/oper/oper-2018-m11/img1.png) no-repeat
      background-size:100% 100%
    .month-11-bg1
      height:6.04rem
      background:url(../../../../assets/images/oper/oper-2018-m11/img2.png) no-repeat
      background-size:100% 100%
    .month-11-bg2
      height:5.82rem
      background:url(../../../../assets/images/oper/oper-2018-m11/img3.png) no-repeat
      background-size:100% 100%
    .month-11-bg3
      height:9.22rem
      background:url(../../../../assets/images/oper/oper-2018-m11/img4.png) no-repeat
      background-size:100% 100%
    .month-11-bg4
      height:15.25rem
      background:url(../../../../assets/images/oper/oper-2018-m11/img5.png) no-repeat
      background-size:100% 100%
    .month-11-bg5
      height:10.91rem
      background:url(../../../../assets/images/oper/oper-2018-m11/img6.png) no-repeat
      background-size:100% 100%
    .month-11-bg6
      height:9.51rem
      background:url(../../../../assets/images/oper/oper-2018-m11/img7.png) no-repeat
      background-size:100% 100%
    .month-11-bg7
      height:10.52rem
      background:url(../../../../assets/images/oper/oper-2018-m11/img8.png) no-repeat
      background-size:100% 100%
    .month-11-bg8
      height:7.04rem
      background:url(../../../../assets/images/oper/oper-2018-m11/img9.png) no-repeat
      background-size:100% 100%
    .month-11-bg9
      height:3.97rem
      background:url(../../../../assets/images/oper/oper-2018-m11/img10.png) no-repeat
      background-size:100% 100%
    .inform-charge
      height: 12.58rem
      background: url(../../../../assets/images/inform/inform-charge.jpg) no-repeat
      background-size: 100% 100%
</style>
