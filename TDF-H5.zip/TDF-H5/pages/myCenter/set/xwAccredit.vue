<template>
  <div class="accredit">
    <td-header title="业务授权"/>
    <ul>
      <li>
        <span>业务授权</span>
        <span v-if="authStatus === 1">已授权</span>
        <span v-if="authStatus === 2">已过期 <b @click="appauth">重新授权</b></span>
      </li>
      <li>
        <span>授权金额 <i 
          class="iconfont" 
          @click="openLayer()">&#xe6f7;</i></span>
        <span>{{ authAmount }}元</span>
      </li>
      <li>
        <span>授权期限</span>
        <span v-if="authStatus === 1">{{ authTime }}到期</span>
        <span v-if="authStatus === 2">已于{{ authTime }}到期</span>
      </li>
    </ul>
    <Layer 
      v-show="layerShow" 
      submit="我知道了" 
      @on-sub="closeLayer()"><span class="accreditLayer">授权金额指授权单笔交易的金额</span></Layer>
  </div>
</template>

<script>
import { information, hanAppauth } from '~/plugins/api.js'

export default {
  data() {
    return {
      layerShow: false,
      authAmount: '',
      authTime: '',
      authStatus: ''
    }
  },
  mounted() {
    information(this.$axios).then(res => {
      if (res) {
        this.authAmount = res.data.content.authAmount
        this.authTime = res.data.content.authTime
        this.authStatus = res.data.content.authStatus
      }
    })
  },
  methods: {
    appauth() {
      hanAppauth(this.$axios).then(res => {
        if (res) {
          let nonce = res.data.content.nonce
          this.$router.push({
            name: 'xwDeposit-transit',
            params: {
              sign: nonce
            }
          })
        }
      })
    },
    openLayer() {
      this.layerShow = true
    },
    closeLayer() {
      this.layerShow = false
    }
  },
  components: {}
}
</script>

<style lang="stylus" scoped>
  .accredit
    padding-top: 88px
    ul
      padding: 0 30px
      background-color: $color-white
      margin-top: 20px
      li
        border-bottom: 1px solid $color-gray5
        overflow: hidden
        span
          font-size: $fontsize-medium
          display: block
          line-height: 100px
          b
            color: #FF6866
          i
            display: inline-block
            padding: 0 10px
            font-size: $fontsize-medium
            color: $color-gray3
        span:nth-child(1)
          color: $color-gray1
          float: left
        span:nth-child(2)
          color: $color-gray3
          float: right
      li:last-child
        border: none
    .accreditLayer
      display: block
      font-size: $fontsize-medium
      color: $color-gray1
      line-height: 50px
      text-align: center
      padding: 50px 0 20px
</style>
