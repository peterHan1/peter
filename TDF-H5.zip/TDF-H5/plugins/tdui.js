import Vue from 'vue'
import TDUI from '../components/index'

Vue.use(TDUI)
