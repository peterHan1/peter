import Vconsole from 'vconsole'
let vConsole = new Vconsole()
export default vConsole
