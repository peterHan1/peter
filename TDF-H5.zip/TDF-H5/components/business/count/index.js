import Count from './src/v-count.vue'

Count.install = function(Vue) {
  Vue.component(Count.name, Count)
}

export default Count
