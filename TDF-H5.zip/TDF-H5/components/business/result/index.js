import Result from './result.vue'
Result.install = function(Vue) {
  Vue.component(component.name, Result)
}
export default Result
