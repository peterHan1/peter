import TdFooter from './footerNav.vue'
TdFooter.install = function(Vue) {
  Vue.component(component.name, TdFooter)
}
export default TdFooter
