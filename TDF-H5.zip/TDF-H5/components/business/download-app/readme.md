this.$App('请在电脑端登录官网或在APP端查看')
