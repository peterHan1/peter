import App from './down-app.js'

export default App
