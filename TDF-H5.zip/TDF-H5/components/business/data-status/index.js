import DataStatus from './data.vue'
DataStatus.install = function(Vue) {
  Vue.component(component.name, DataStatus)
}
export default DataStatus
