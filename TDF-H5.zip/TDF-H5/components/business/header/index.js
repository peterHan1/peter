import TdHeader from './header.vue'
TdHeader.install = function(Vue) {
  Vue.component(component.name, TdHeader)
}
export default TdHeader
