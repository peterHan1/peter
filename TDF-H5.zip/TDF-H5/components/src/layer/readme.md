<Layer v-show="layerCode" @on-close="codeClose()" @on-sub="codeSub()" @shade-close="shadeClose()" close="取消" submit="确定">
  <自定义内容>
</Layer>
close、submit需要哪个按钮传内容
codeClose（）、codeSub（）两个按钮函数 
shadeClose() 点击遮罩关闭函数