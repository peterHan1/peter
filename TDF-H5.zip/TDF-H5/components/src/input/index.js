import Input from './input.vue'
Input.install = function(Vue) {
  Vue.component(component.name, Input)
}
export default Input
