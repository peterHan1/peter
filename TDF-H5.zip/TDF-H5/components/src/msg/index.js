import Msg from './src/msg.js'

export default Msg
