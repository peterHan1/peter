不传默认三秒关闭 
this.$Msg('这是错误信息', 2000)
this.$Msg(null, 2000, 'ok') 'ok':加载完成, 'no':加载失败, 'warning':'警示信息'。不传同上

