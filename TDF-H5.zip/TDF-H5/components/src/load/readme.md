
打开加载
this.$Loading.Load()

关闭加载
this.$Loading.Close()
