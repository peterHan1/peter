import Loading from './loading.vue'
Loading.install = function(Vue) {
  Vue.component(component.name, Loading)
}
export default Loading
