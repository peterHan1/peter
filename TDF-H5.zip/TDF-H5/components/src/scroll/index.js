import Scroll from './scroll.vue'
Scroll.install = function(Vue) {
  Vue.component(component.name, Scroll)
}
export default Scroll
